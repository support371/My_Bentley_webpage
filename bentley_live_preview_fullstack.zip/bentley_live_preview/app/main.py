from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Any
from fastapi import FastAPI, Request, Body
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI(title="Bentley Enterprise Platform Preview", version="3.0-preview")
templates = Jinja2Templates(directory="/mnt/data/bentley_live_preview/app/templates")
app.mount("/static", StaticFiles(directory="/mnt/data/bentley_live_preview/app/static"), name="static")
NOW = datetime(2026, 4, 3, 12, 0, tzinfo=timezone.utc)
EVENTS = [
    {"id":"evt-1001","time":(NOW-timedelta(minutes=12)).isoformat(),"event_type":"iModelCreated","itwin":"Manhattan Tower A","imodel":"Tower A Core Model","user":"ops@bentley.local","details":"New structural model created for Tower A.","severity":"info"},
    {"id":"evt-1002","time":(NOW-timedelta(hours=1,minutes=5)).isoformat(),"event_type":"VersionCreated","itwin":"Cyber Command Center","imodel":"Security Layout Model","user":"automation@bentley.local","details":"Version 18 published after QA checks.","severity":"success"},
    {"id":"evt-1003","time":(NOW-timedelta(hours=2,minutes=20)).isoformat(),"event_type":"ChangesReady","itwin":"Hudson Logistics Park","imodel":"Warehouse Network Model","user":"engineer@bentley.local","details":"Pending version approval after 4 synced changesets.","severity":"warning"},
    {"id":"evt-1004","time":(NOW-timedelta(hours=4,minutes=10)).isoformat(),"event_type":"iModelDeleted","itwin":"Legacy Archive","imodel":"Deprecated Model","user":"admin@bentley.local","details":"Archived obsolete model after retention review.","severity":"danger"},
]
ITWINS=[
    {"id":"tw-01","name":"Manhattan Tower A","status":"Healthy","imodels":4,"last_event":"12m ago"},
    {"id":"tw-02","name":"Cyber Command Center","status":"Healthy","imodels":3,"last_event":"1h ago"},
    {"id":"tw-03","name":"Hudson Logistics Park","status":"Warning","imodels":6,"last_event":"2h ago"},
]
IMODELS=[
    {"id":"mdl-01","name":"Tower A Core Model","itwin":"Manhattan Tower A","versions":12,"changes_ready":1,"health":"Healthy"},
    {"id":"mdl-02","name":"Security Layout Model","itwin":"Cyber Command Center","versions":18,"changes_ready":0,"health":"Healthy"},
    {"id":"mdl-03","name":"Warehouse Network Model","itwin":"Hudson Logistics Park","versions":9,"changes_ready":4,"health":"Warning"},
]
INTEGRATIONS=[
    {"name":"Azure DevOps","category":"Development","status":"Connected","health":"Healthy"},
    {"name":"GitHub","category":"Development","status":"Connected","health":"Healthy"},
    {"name":"Cloudflare","category":"Infrastructure","status":"Connected","health":"Healthy"},
    {"name":"Slack","category":"Automation","status":"Connected","health":"Warning"},
    {"name":"Telegram","category":"Marketing","status":"Connected","health":"Healthy"},
    {"name":"OneSignal","category":"Marketing","status":"Pending","health":"Setup Needed"},
    {"name":"Stripe","category":"Commercial","status":"Pending","health":"Setup Needed"},
]
CONTROL_PLANE=[
    {"name":"Website Studio","status":"In Progress","summary":"Multi-page branded website builder, landing pages and publishing flow."},
    {"name":"Infrastructure Console","status":"Ready","summary":"Deployment status, environments, domains, secrets and runtime health."},
    {"name":"Marketplace & News","status":"In Progress","summary":"News feed, newsletter, product showcases and market launch surfaces."},
    {"name":"Client Delivery","status":"Planned","summary":"Client portals, portfolios, service dashboards and account workspaces."},
    {"name":"Automation Environment","status":"In Progress","summary":"Alert routing, bot actions, webhook flows and service automations."},
    {"name":"Marketing Environment","status":"In Progress","summary":"Social scheduling, campaign cards, content publishing and funnel tracking."},
    {"name":"Development Environment","status":"Ready","summary":"Diagnostics, pipelines, service catalog and integration readiness."},
]
LAUNCH_CHECKS=[
    {"label":"Custom Domain","status":"warning","detail":"Production domain not finalized."},
    {"label":"Bentley Credentials","status":"ready","detail":"Service credentials configured in preview mode."},
    {"label":"Webhook Verification","status":"warning","detail":"Signature verification should be enforced in production."},
    {"label":"Secure Cookies","status":"warning","detail":"Secure cookie policy pending final production cutover."},
    {"label":"Database Backend","status":"ready","detail":"Preview backend serving seeded operational data."},
    {"label":"Alert Routing","status":"in_progress","detail":"Slack and Telegram connected; PagerDuty/Email pending."},
    {"label":"Website Chat","status":"in_progress","detail":"Chat provider selector exists; embed script pending."},
    {"label":"Observability","status":"ready","detail":"Diagnostics and service health panels available."},
    {"label":"Privacy & Terms","status":"warning","detail":"Legal pages must be finalized before production launch."},
]
MODULES={
    "Home":{"title":"Bentley Enterprise Platform","subtitle":"Unified Bentley operations, Mobile Ops, launch readiness, integrations, and enterprise control-plane preview."},
    "Dashboard":{"title":"iTwin Activity Monitor Dashboard","subtitle":"Real-time operational intelligence for Bentley webhook activity, health scoring, and anomaly detection."},
    "Events":{"title":"Event Intelligence","subtitle":"Chronological event stream, payload inspection, severity clustering and export-ready operational history."},
    "iTwins":{"title":"iTwins Portfolio","subtitle":"Portfolio-wide visibility into active iTwins, status, and model inventory."},
    "iModels":{"title":"iModels Explorer","subtitle":"Deep inspection of model versions, changes-ready backlog and asset health."},
    "Integrations":{"title":"Integration Center","subtitle":"Connected services across development, marketing, automation, infrastructure and commerce."},
    "Admin":{"title":"Administration","subtitle":"User management, alert configuration, diagnostics and policy control."},
    "Mobile Ops":{"title":"Mobile Ops","subtitle":"Operational views for alarms, monitors, reports, admin and integrations."},
    "Launch Readiness":{"title":"Launch Readiness","subtitle":"Pre-production readiness checks across domains, security, observability and compliance."},
    "Control Plane":{"title":"Control Plane","subtitle":"Enterprise execution layer for website studio, infrastructure, marketplace, client delivery and environments."},
}

def dashboard_metrics() -> dict[str, Any]:
    created=sum(1 for e in EVENTS if e['event_type']=='iModelCreated')
    deleted=sum(1 for e in EVENTS if e['event_type']=='iModelDeleted')
    versions=sum(1 for e in EVENTS if e['event_type']=='VersionCreated')
    changes=sum(1 for e in EVENTS if e['event_type']=='ChangesReady')
    net=created-deleted
    version_rate=round((versions/changes)*100,1) if changes else 100.0
    health=78
    return {'created':created,'deleted':deleted,'versions':versions,'changes_ready':changes,'net_growth':net,'version_rate':version_rate,'health_score':health,'health_status':'Healthy','last_updated':NOW.isoformat()}

def common_context(active:str):
    return {'nav': [('Home','/'),('Dashboard','/dashboard'),('Events','/events-view'),('iTwins','/itwins-view'),('iModels','/imodels-view'),('Integrations','/integrations'),('Admin','/admin'),('Mobile Ops','/mobile/alarms'),('Launch Readiness','/launch-readiness'),('Control Plane','/control-plane')], 'active': active, 'modules': MODULES}

@app.get('/', response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse('home.html', {**common_context('Home'), 'request': request, 'events': EVENTS[:3], 'integrations': INTEGRATIONS[:4], 'modules_list': CONTROL_PLANE})

@app.get('/dashboard', response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse('dashboard.html', {**common_context('Dashboard'), 'request': request, 'metrics': dashboard_metrics(), 'events': EVENTS})

@app.get('/dashboard/feed')
async def dashboard_feed():
    return {'kpis': dashboard_metrics(), 'health_breakdown':['Recent version under 48h','Change pipeline active','One warning due to orphaned changes'], 'events': EVENTS, 'timeline':[{'label':e['event_type'],'time':e['time'],'severity':e['severity']} for e in EVENTS]}

@app.post('/dashboard/test-webhook')
async def dashboard_test_webhook():
    e={'id':f'evt-{1000+len(EVENTS)+1}','time':datetime.now(timezone.utc).isoformat(),'event_type':'iModelCreated','itwin':'Preview Sandbox','imodel':'Generated Test Model','user':'tester@preview.local','details':'Synthetic event injected from preview.','severity':'info'}
    EVENTS.insert(0,e)
    return {'ok':True,'event':e,'message':'Test webhook created.'}

@app.get('/events-view', response_class=HTMLResponse)
async def events_view(request: Request):
    return templates.TemplateResponse('events.html', {**common_context('Events'),'request':request,'events':EVENTS})

@app.get('/api/events')
async def api_events(): return {'items':EVENTS,'total':len(EVENTS)}

@app.get('/itwins-view', response_class=HTMLResponse)
async def itwins_view(request: Request):
    return templates.TemplateResponse('itwins.html', {**common_context('iTwins'),'request':request,'items':ITWINS})

@app.get('/api/itwins')
async def api_itwins(): return {'items':ITWINS}

@app.get('/imodels-view', response_class=HTMLResponse)
async def imodels_view(request: Request):
    return templates.TemplateResponse('imodels.html', {**common_context('iModels'),'request':request,'items':IMODELS})

@app.get('/api/imodels')
async def api_imodels(): return {'items':IMODELS}

@app.get('/integrations', response_class=HTMLResponse)
async def integrations(request: Request):
    return templates.TemplateResponse('integrations.html', {**common_context('Integrations'),'request':request,'items':INTEGRATIONS})

@app.get('/api/integrations')
async def api_integrations(): return {'items':INTEGRATIONS}

@app.get('/admin', response_class=HTMLResponse)
async def admin(request: Request):
    return templates.TemplateResponse('admin.html', {**common_context('Admin'),'request':request,'checks':LAUNCH_CHECKS,'integrations':INTEGRATIONS})

@app.get('/api/admin/summary')
async def api_admin_summary(): return {'users':14,'teams':6,'alerts_configured':4,'channels':['Slack','Telegram'],'rate_limit':'Enabled','diagnostics':'Active'}

@app.get('/mobile/alarms', response_class=HTMLResponse)
async def mobile_alarms(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'alarms','items':EVENTS})

@app.get('/mobile/monitors', response_class=HTMLResponse)
async def mobile_monitors(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'monitors','items':ITWINS})

@app.get('/mobile/reports', response_class=HTMLResponse)
async def mobile_reports(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'reports','items':[dashboard_metrics()]})

@app.get('/mobile/admin', response_class=HTMLResponse)
async def mobile_admin(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'admin','items':LAUNCH_CHECKS})

@app.get('/mobile/more', response_class=HTMLResponse)
async def mobile_more(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'more','items':CONTROL_PLANE})

@app.get('/mobile/integrations', response_class=HTMLResponse)
async def mobile_integrations(request: Request):
    return templates.TemplateResponse('mobile.html', {**common_context('Mobile Ops'),'request':request,'tab':'integrations','items':INTEGRATIONS})

@app.get('/api/mobile/summary')
async def api_mobile_summary(): return {'kpis':dashboard_metrics(),'tabs':['alarms','monitors','reports','admin','more','integrations']}

@app.get('/launch-readiness', response_class=HTMLResponse)
async def launch_readiness(request: Request):
    return templates.TemplateResponse('launch.html', {**common_context('Launch Readiness'),'request':request,'checks':LAUNCH_CHECKS})

@app.get('/api/launch-readiness')
async def api_launch_readiness(): return {'items':LAUNCH_CHECKS,'score':68,'status':'In Progress'}

@app.get('/control-plane', response_class=HTMLResponse)
async def control_plane(request: Request):
    return templates.TemplateResponse('control.html', {**common_context('Control Plane'),'request':request,'modules_list':CONTROL_PLANE,'integrations':INTEGRATIONS})

@app.get('/api/control-plane')
async def api_control_plane(): return {'modules':CONTROL_PLANE,'environments':['Development','Marketing','Automation','Operations']}

@app.get('/health')
async def health(): return {'status':'healthy','service':app.title,'version':app.version,'time':NOW.isoformat()}

@app.post('/api/agent/explain-health')
async def explain_health(payload: dict = Body(default={})): return {'summary':'Health is stable but version completion is lagging behind changes-ready activity in Hudson Logistics Park.','recommended_actions':['Review Warehouse Network Model backlog','Confirm version publication workflow','Route warning to Slack and Telegram']}

@app.exception_handler(404)
async def not_found(_: Request, __):
    return RedirectResponse('/')
