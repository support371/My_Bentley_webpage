from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class WebsiteProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    slug: str = Field(min_length=2, max_length=140)
    vertical: str = Field(default="Cybersecurity", max_length=80)
    status: str = Field(default="draft", max_length=40)
    primary_domain: Optional[str] = Field(default=None, max_length=255)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    summary: Optional[str] = Field(default=None, max_length=2000)
    is_public: bool = True


class WebsiteProjectUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    slug: Optional[str] = Field(default=None, min_length=2, max_length=140)
    vertical: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    primary_domain: Optional[str] = Field(default=None, max_length=255)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    summary: Optional[str] = Field(default=None, max_length=2000)
    is_public: Optional[bool] = None


class WebsitePageCreate(BaseModel):
    project_id: str
    title: str = Field(min_length=2, max_length=120)
    slug: str = Field(min_length=2, max_length=140)
    page_type: str = Field(default="service", max_length=80)
    status: str = Field(default="draft", max_length=40)
    hero_title: Optional[str] = Field(default=None, max_length=160)
    seo_title: Optional[str] = Field(default=None, max_length=160)
    seo_description: Optional[str] = Field(default=None, max_length=320)
    sort_order: int = 0


class WebsitePageUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=120)
    slug: Optional[str] = Field(default=None, min_length=2, max_length=140)
    page_type: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    hero_title: Optional[str] = Field(default=None, max_length=160)
    seo_title: Optional[str] = Field(default=None, max_length=160)
    seo_description: Optional[str] = Field(default=None, max_length=320)
    sort_order: Optional[int] = None


class PageSectionCreate(BaseModel):
    page_id: str
    section_key: str = Field(min_length=2, max_length=120)
    title: str = Field(min_length=2, max_length=120)
    body: Optional[str] = Field(default=None, max_length=5000)
    component_type: str = Field(default="content", max_length=80)
    sort_order: int = 0
    is_enabled: bool = True


class PageSectionUpdate(BaseModel):
    section_key: Optional[str] = Field(default=None, min_length=2, max_length=120)
    title: Optional[str] = Field(default=None, min_length=2, max_length=120)
    body: Optional[str] = Field(default=None, max_length=5000)
    component_type: Optional[str] = Field(default=None, max_length=80)
    sort_order: Optional[int] = None
    is_enabled: Optional[bool] = None


class BrandAssetCreate(BaseModel):
    project_id: str
    asset_type: str = Field(default="image", max_length=80)
    name: str = Field(min_length=2, max_length=120)
    file_url: Optional[str] = Field(default=None, max_length=500)
    usage_context: Optional[str] = Field(default=None, max_length=160)
    is_primary: bool = False


class BrandAssetUpdate(BaseModel):
    asset_type: Optional[str] = Field(default=None, max_length=80)
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    file_url: Optional[str] = Field(default=None, max_length=500)
    usage_context: Optional[str] = Field(default=None, max_length=160)
    is_primary: Optional[bool] = None


class PublishReleaseCreate(BaseModel):
    project_id: str
    version_label: str = Field(min_length=1, max_length=80)
    environment: str = Field(default="preview", max_length=40)
    status: str = Field(default="pending", max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class PublishReleaseUpdate(BaseModel):
    version_label: Optional[str] = Field(default=None, min_length=1, max_length=80)
    environment: Optional[str] = Field(default=None, max_length=40)
    status: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class DeploymentProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    provider: str = Field(default="Cloudflare", max_length=80)
    target_stack: str = Field(default="FastAPI + Edge", max_length=120)
    status: str = Field(default="planned", max_length=40)
    primary_domain: Optional[str] = Field(default=None, max_length=255)
    repo_url: Optional[str] = Field(default=None, max_length=255)
    summary: Optional[str] = Field(default=None, max_length=2000)


class DeploymentProjectUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    provider: Optional[str] = Field(default=None, max_length=80)
    target_stack: Optional[str] = Field(default=None, max_length=120)
    status: Optional[str] = Field(default=None, max_length=40)
    primary_domain: Optional[str] = Field(default=None, max_length=255)
    repo_url: Optional[str] = Field(default=None, max_length=255)
    summary: Optional[str] = Field(default=None, max_length=2000)


class EnvironmentProfileCreate(BaseModel):
    deployment_project_id: str
    name: str = Field(min_length=2, max_length=120)
    stage: str = Field(default="preview", max_length=40)
    app_url: Optional[str] = Field(default=None, max_length=255)
    deployment_status: str = Field(default="pending", max_length=40)
    health_status: str = Field(default="unknown", max_length=40)
    region: Optional[str] = Field(default=None, max_length=80)


class EnvironmentProfileUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    stage: Optional[str] = Field(default=None, max_length=40)
    app_url: Optional[str] = Field(default=None, max_length=255)
    deployment_status: Optional[str] = Field(default=None, max_length=40)
    health_status: Optional[str] = Field(default=None, max_length=40)
    region: Optional[str] = Field(default=None, max_length=80)


class DomainBindingCreate(BaseModel):
    deployment_project_id: str
    hostname: str = Field(min_length=3, max_length=255)
    dns_provider: str = Field(default="Cloudflare", max_length=80)
    ssl_mode: str = Field(default="strict", max_length=40)
    status: str = Field(default="pending", max_length=40)
    cdn_enabled: bool = True


class DomainBindingUpdate(BaseModel):
    hostname: Optional[str] = Field(default=None, min_length=3, max_length=255)
    dns_provider: Optional[str] = Field(default=None, max_length=80)
    ssl_mode: Optional[str] = Field(default=None, max_length=40)
    status: Optional[str] = Field(default=None, max_length=40)
    cdn_enabled: Optional[bool] = None


class ReleaseAuditEventCreate(BaseModel):
    deployment_project_id: str
    event_type: str = Field(min_length=2, max_length=120)
    actor_name: Optional[str] = Field(default=None, max_length=120)
    target_environment: Optional[str] = Field(default=None, max_length=120)
    detail: Optional[str] = Field(default=None, max_length=2000)


class CloudflareZoneCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    zone_name: str = Field(min_length=3, max_length=255)
    status: str = Field(default="active", max_length=40)
    ssl_mode: str = Field(default="strict", max_length=40)
    waf_mode: str = Field(default="managed", max_length=40)
    cache_strategy: str = Field(default="standard", max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class CloudflareZoneUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    zone_name: Optional[str] = Field(default=None, min_length=3, max_length=255)
    status: Optional[str] = Field(default=None, max_length=40)
    ssl_mode: Optional[str] = Field(default=None, max_length=40)
    waf_mode: Optional[str] = Field(default=None, max_length=40)
    cache_strategy: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class CloudflareRuleCreate(BaseModel):
    zone_id: str
    rule_name: str = Field(min_length=2, max_length=120)
    rule_type: str = Field(default="waf", max_length=80)
    action: str = Field(default="monitor", max_length=80)
    expression: str = Field(min_length=3, max_length=500)
    status: str = Field(default="active", max_length=40)
    priority: int = 100


class CloudflareRuleUpdate(BaseModel):
    rule_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    rule_type: Optional[str] = Field(default=None, max_length=80)
    action: Optional[str] = Field(default=None, max_length=80)
    expression: Optional[str] = Field(default=None, min_length=3, max_length=500)
    status: Optional[str] = Field(default=None, max_length=40)
    priority: Optional[int] = None


class BillingPlanCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    vertical: str = Field(default="Cybersecurity", max_length=80)
    billing_provider: str = Field(default="Stripe", max_length=80)
    cadence: str = Field(default="monthly", max_length=40)
    price_label: str = Field(default="Custom", max_length=80)
    currency: str = Field(default="USD", max_length=12)
    status: str = Field(default="draft", max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class BillingPlanUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    vertical: Optional[str] = Field(default=None, max_length=80)
    billing_provider: Optional[str] = Field(default=None, max_length=80)
    cadence: Optional[str] = Field(default=None, max_length=40)
    price_label: Optional[str] = Field(default=None, max_length=80)
    currency: Optional[str] = Field(default=None, max_length=12)
    status: Optional[str] = Field(default=None, max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class PaymentGatewayCreate(BaseModel):
    gateway_name: str = Field(min_length=2, max_length=120)
    gateway_type: str = Field(default="fiat", max_length=80)
    settlement_asset: Optional[str] = Field(default=None, max_length=40)
    status: str = Field(default="configured", max_length=40)
    webhook_status: str = Field(default="pending", max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class PaymentGatewayUpdate(BaseModel):
    gateway_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    gateway_type: Optional[str] = Field(default=None, max_length=80)
    settlement_asset: Optional[str] = Field(default=None, max_length=40)
    status: Optional[str] = Field(default=None, max_length=40)
    webhook_status: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=2000)


class WalletAccountCreate(BaseModel):
    wallet_name: str = Field(min_length=2, max_length=120)
    wallet_type: str = Field(default="user-controlled", max_length=80)
    owner_scope: str = Field(default="personal", max_length=80)
    network: str = Field(default="Base", max_length=80)
    custody_model: str = Field(default="self-custody", max_length=80)
    address_hint: Optional[str] = Field(default=None, max_length=120)
    status: str = Field(default="configured", max_length=40)


class WalletAccountUpdate(BaseModel):
    wallet_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    wallet_type: Optional[str] = Field(default=None, max_length=80)
    owner_scope: Optional[str] = Field(default=None, max_length=80)
    network: Optional[str] = Field(default=None, max_length=80)
    custody_model: Optional[str] = Field(default=None, max_length=80)
    address_hint: Optional[str] = Field(default=None, max_length=120)
    status: Optional[str] = Field(default=None, max_length=40)


class MarketplaceOfferCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    vertical: str = Field(default="Cybersecurity", max_length=80)
    channel: str = Field(default="Direct", max_length=80)
    price_model: str = Field(default="Subscription", max_length=80)
    status: str = Field(default="draft", max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class MarketplaceOfferUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    vertical: Optional[str] = Field(default=None, max_length=80)
    channel: Optional[str] = Field(default=None, max_length=80)
    price_model: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class NewsArticleCreate(BaseModel):
    title: str = Field(min_length=2, max_length=180)
    slug: str = Field(min_length=2, max_length=180)
    source_name: str = Field(default="Telegram", max_length=120)
    status: str = Field(default="queued", max_length=40)
    image_url: Optional[str] = Field(default=None, max_length=500)
    description: Optional[str] = Field(default=None, max_length=500)
    body: Optional[str] = Field(default=None, max_length=10000)


class NewsArticleUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=180)
    slug: Optional[str] = Field(default=None, min_length=2, max_length=180)
    source_name: Optional[str] = Field(default=None, max_length=120)
    status: Optional[str] = Field(default=None, max_length=40)
    image_url: Optional[str] = Field(default=None, max_length=500)
    description: Optional[str] = Field(default=None, max_length=500)
    body: Optional[str] = Field(default=None, max_length=10000)


class NewsletterIssueCreate(BaseModel):
    title: str = Field(min_length=2, max_length=180)
    audience: str = Field(default="All Subscribers", max_length=180)
    status: str = Field(default="draft", max_length=40)
    send_window: Optional[str] = Field(default=None, max_length=80)
    hero_story: Optional[str] = Field(default=None, max_length=500)


class NewsletterIssueUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=180)
    audience: Optional[str] = Field(default=None, max_length=180)
    status: Optional[str] = Field(default=None, max_length=40)
    send_window: Optional[str] = Field(default=None, max_length=80)
    hero_story: Optional[str] = Field(default=None, max_length=500)


class ClientAccountCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    vertical: str = Field(default="Cybersecurity", max_length=80)
    primary_contact: Optional[str] = Field(default=None, max_length=120)
    service_tier: str = Field(default="Enterprise", max_length=80)
    status: str = Field(default="active", max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class ClientAccountUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    vertical: Optional[str] = Field(default=None, max_length=80)
    primary_contact: Optional[str] = Field(default=None, max_length=120)
    service_tier: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class TeamWorkspaceCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    client_account_id: Optional[str] = None
    vertical: str = Field(default="Cybersecurity", max_length=80)
    team_type: str = Field(default="operations", max_length=80)
    member_capacity: int = 10
    status: str = Field(default="active", max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class TeamWorkspaceUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    client_account_id: Optional[str] = None
    vertical: Optional[str] = Field(default=None, max_length=80)
    team_type: Optional[str] = Field(default=None, max_length=80)
    member_capacity: Optional[int] = None
    status: Optional[str] = Field(default=None, max_length=40)
    summary: Optional[str] = Field(default=None, max_length=2000)


class ServicePortfolioCreate(BaseModel):
    client_account_id: str
    team_workspace_id: Optional[str] = None
    service_name: str = Field(min_length=2, max_length=180)
    category: str = Field(default="Managed Service", max_length=80)
    status: str = Field(default="active", max_length=40)
    renewal_window: Optional[str] = Field(default=None, max_length=120)
    notes: Optional[str] = Field(default=None, max_length=2000)


class ServicePortfolioUpdate(BaseModel):
    client_account_id: Optional[str] = None
    team_workspace_id: Optional[str] = None
    service_name: Optional[str] = Field(default=None, min_length=2, max_length=180)
    category: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    renewal_window: Optional[str] = Field(default=None, max_length=120)
    notes: Optional[str] = Field(default=None, max_length=2000)
