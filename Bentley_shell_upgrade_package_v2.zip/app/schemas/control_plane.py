from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class WorkspaceCreate(BaseModel):
    module_slug: str
    name: str = Field(min_length=2, max_length=120)
    vertical: str = Field(default="Cybersecurity", max_length=80)
    status: str = Field(default="planned", max_length=40)
    environment: str = Field(default="preview", max_length=40)
    priority: str = Field(default="high", max_length=20)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    summary: Optional[str] = Field(default=None, max_length=2000)
    metadata_json: Optional[str] = None


class WorkspaceUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    vertical: Optional[str] = Field(default=None, max_length=80)
    status: Optional[str] = Field(default=None, max_length=40)
    environment: Optional[str] = Field(default=None, max_length=40)
    priority: Optional[str] = Field(default=None, max_length=20)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    summary: Optional[str] = Field(default=None, max_length=2000)
    metadata_json: Optional[str] = None
    is_active: Optional[bool] = None


class WorkspaceRead(BaseModel):
    id: str
    module_slug: str
    name: str
    vertical: str
    status: str
    environment: str
    priority: str
    owner_name: Optional[str] = None
    summary: Optional[str] = None
    metadata_json: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
        orm_mode = True
