from sqlmodel import SQLModel, Field, Column
from sqlalchemy import Text
from typing import Optional
from datetime import datetime
import uuid


class ControlPlaneWorkspace(SQLModel, table=True):
    __tablename__ = "control_plane_workspaces"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    module_slug: str = Field(index=True)
    name: str = Field(index=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    status: str = Field(default="planned", index=True)
    environment: str = Field(default="preview", index=True)
    priority: str = Field(default="high", index=True)
    owner_name: Optional[str] = None
    summary: Optional[str] = Field(default=None, sa_column=Column(Text))
    metadata_json: Optional[str] = Field(default=None, sa_column=Column(Text))
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
