from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from sqlmodel import Field, SQLModel


class WebsiteProject(SQLModel, table=True):
    __tablename__ = "website_projects"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    slug: str = Field(index=True, unique=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    status: str = Field(default="draft", index=True)
    primary_domain: Optional[str] = None
    owner_name: Optional[str] = None
    summary: Optional[str] = None
    is_public: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class WebsitePage(SQLModel, table=True):
    __tablename__ = "website_pages"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    project_id: str = Field(foreign_key="website_projects.id", index=True)
    title: str = Field(index=True)
    slug: str = Field(index=True)
    page_type: str = Field(default="service")
    status: str = Field(default="draft", index=True)
    hero_title: Optional[str] = None
    seo_title: Optional[str] = None
    seo_description: Optional[str] = None
    sort_order: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class PageSection(SQLModel, table=True):
    __tablename__ = "page_sections"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    page_id: str = Field(foreign_key="website_pages.id", index=True)
    section_key: str = Field(index=True)
    title: str
    body: Optional[str] = None
    component_type: str = Field(default="content")
    sort_order: int = 0
    is_enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class BrandAsset(SQLModel, table=True):
    __tablename__ = "brand_assets"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    project_id: str = Field(foreign_key="website_projects.id", index=True)
    asset_type: str = Field(default="image", index=True)
    name: str
    file_url: Optional[str] = None
    usage_context: Optional[str] = None
    is_primary: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class PublishRelease(SQLModel, table=True):
    __tablename__ = "publish_releases"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    project_id: str = Field(foreign_key="website_projects.id", index=True)
    version_label: str = Field(index=True)
    environment: str = Field(default="preview", index=True)
    status: str = Field(default="pending", index=True)
    notes: Optional[str] = None
    published_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class DeploymentProject(SQLModel, table=True):
    __tablename__ = "deployment_projects"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    provider: str = Field(default="Cloudflare", index=True)
    target_stack: str = Field(default="FastAPI + Edge", index=True)
    status: str = Field(default="planned", index=True)
    primary_domain: Optional[str] = None
    repo_url: Optional[str] = None
    summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class EnvironmentProfile(SQLModel, table=True):
    __tablename__ = "environment_profiles"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    deployment_project_id: str = Field(foreign_key="deployment_projects.id", index=True)
    name: str = Field(index=True)
    stage: str = Field(default="preview", index=True)
    app_url: Optional[str] = None
    deployment_status: str = Field(default="pending", index=True)
    health_status: str = Field(default="unknown", index=True)
    region: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class DomainBinding(SQLModel, table=True):
    __tablename__ = "domain_bindings"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    deployment_project_id: str = Field(foreign_key="deployment_projects.id", index=True)
    hostname: str = Field(index=True)
    dns_provider: str = Field(default="Cloudflare")
    ssl_mode: str = Field(default="strict")
    status: str = Field(default="pending", index=True)
    cdn_enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ReleaseAuditEvent(SQLModel, table=True):
    __tablename__ = "release_audit_events"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    deployment_project_id: str = Field(foreign_key="deployment_projects.id", index=True)
    event_type: str = Field(index=True)
    actor_name: Optional[str] = None
    target_environment: Optional[str] = None
    detail: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class CloudflareZone(SQLModel, table=True):
    __tablename__ = "cloudflare_zones"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    zone_name: str = Field(index=True, unique=True)
    status: str = Field(default="active", index=True)
    ssl_mode: str = Field(default="strict")
    waf_mode: str = Field(default="managed")
    cache_strategy: str = Field(default="standard")
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class CloudflareRule(SQLModel, table=True):
    __tablename__ = "cloudflare_rules"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    zone_id: str = Field(foreign_key="cloudflare_zones.id", index=True)
    rule_name: str = Field(index=True)
    rule_type: str = Field(default="waf")
    action: str = Field(default="monitor")
    expression: str
    status: str = Field(default="active", index=True)
    priority: int = 100
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class BillingPlan(SQLModel, table=True):
    __tablename__ = "billing_plans"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    billing_provider: str = Field(default="Stripe")
    cadence: str = Field(default="monthly")
    price_label: str = Field(default="Custom")
    currency: str = Field(default="USD")
    status: str = Field(default="draft", index=True)
    summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class PaymentGateway(SQLModel, table=True):
    __tablename__ = "payment_gateways"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    gateway_name: str = Field(index=True)
    gateway_type: str = Field(default="fiat")
    settlement_asset: Optional[str] = None
    status: str = Field(default="configured", index=True)
    webhook_status: str = Field(default="pending")
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class WalletAccount(SQLModel, table=True):
    __tablename__ = "wallet_accounts"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    wallet_name: str = Field(index=True)
    wallet_type: str = Field(default="user-controlled")
    owner_scope: str = Field(default="personal")
    network: str = Field(default="Base")
    custody_model: str = Field(default="self-custody")
    address_hint: Optional[str] = None
    status: str = Field(default="configured", index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class MarketplaceOffer(SQLModel, table=True):
    __tablename__ = "marketplace_offers"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    channel: str = Field(default="Direct")
    price_model: str = Field(default="Subscription")
    status: str = Field(default="draft", index=True)
    summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class NewsArticle(SQLModel, table=True):
    __tablename__ = "news_articles"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    title: str = Field(index=True)
    slug: str = Field(index=True, unique=True)
    source_name: str = Field(default="Telegram")
    status: str = Field(default="queued", index=True)
    image_url: Optional[str] = None
    description: Optional[str] = None
    body: Optional[str] = None
    published_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class NewsletterIssue(SQLModel, table=True):
    __tablename__ = "newsletter_issues"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    title: str = Field(index=True)
    audience: str = Field(default="All Subscribers")
    status: str = Field(default="draft", index=True)
    send_window: Optional[str] = None
    hero_story: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ClientAccount(SQLModel, table=True):
    __tablename__ = "client_accounts"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    primary_contact: Optional[str] = None
    service_tier: str = Field(default="Enterprise")
    status: str = Field(default="active", index=True)
    summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class TeamWorkspace(SQLModel, table=True):
    __tablename__ = "team_workspaces"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(index=True)
    client_account_id: Optional[str] = Field(default=None, foreign_key="client_accounts.id", index=True)
    vertical: str = Field(default="Cybersecurity", index=True)
    team_type: str = Field(default="operations")
    member_capacity: int = 10
    status: str = Field(default="active", index=True)
    summary: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ServicePortfolio(SQLModel, table=True):
    __tablename__ = "service_portfolios"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    client_account_id: str = Field(foreign_key="client_accounts.id", index=True)
    team_workspace_id: Optional[str] = Field(default=None, foreign_key="team_workspaces.id", index=True)
    service_name: str = Field(index=True)
    category: str = Field(default="Managed Service")
    status: str = Field(default="active", index=True)
    renewal_window: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
