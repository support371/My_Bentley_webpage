from datetime import datetime
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.core.config import settings
from app.core.security import get_optional_user
from app.db.database import get_session
from app.models.events import Event, WebhookDelivery
from app.models.integrations import Integration
from app.models.resources import IModel, ITwin

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


async def _summary(session: AsyncSession) -> Dict[str, Any]:
    total_events = int(await session.scalar(select(func.count(Event.id))) or 0)
    total_itwins = int(await session.scalar(select(func.count(ITwin.id))) or 0)
    total_imodels = int(await session.scalar(select(func.count(IModel.id))) or 0)
    integrations_connected = int(await session.scalar(select(func.count(Integration.id)).where(Integration.status == "connected")) or 0)
    return {
        "generatedAt": datetime.utcnow().isoformat() + "Z",
        "kpis": {
            "totalEvents": total_events,
            "activeITwins": total_itwins,
            "activeIModels": total_imodels,
            "integrationsConnected": integrations_connected,
        },
        "tabs": ["alarms", "monitors", "reports", "admin", "more", "integrations"],
    }


async def _alarms(session: AsyncSession, limit: int = 20) -> Dict[str, Any]:
    result = await session.execute(select(Event).order_by(Event.received_at.desc()).limit(limit))
    rows = result.scalars().all()
    return {"items": [{
        "id": row.id,
        "title": row.event_type,
        "severity": row.severity,
        "status": row.processing_status,
        "project": row.itwin_name or row.itwin_id or "Unassigned",
        "model": row.imodel_name or row.imodel_id or "—",
        "receivedAt": row.received_at.isoformat() if row.received_at else None,
    } for row in rows]}


async def _monitors(session: AsyncSession, limit: int = 20) -> Dict[str, Any]:
    result = await session.execute(select(ITwin).order_by(ITwin.last_event_at.desc()).limit(limit))
    rows = result.scalars().all()
    return {"items": [{
        "id": row.id,
        "name": row.display_name or row.id,
        "status": row.status or "active",
        "type": row.type or "iTwin",
        "lastEventAt": row.last_event_at.isoformat() if row.last_event_at else None,
    } for row in rows]}


async def _reports(session: AsyncSession) -> Dict[str, Any]:
    deliveries = int(await session.scalar(select(func.count(WebhookDelivery.id))) or 0)
    errors = int(await session.scalar(select(func.count(WebhookDelivery.id)).where(WebhookDelivery.processing_status == "error")) or 0)
    return {"cards": [
        {"title": "Deliveries", "value": deliveries, "detail": "Webhook deliveries processed by the platform."},
        {"title": "Errors", "value": errors, "detail": "Delivery failures requiring review."},
        {"title": "CSV Export", "value": "/events/export", "detail": "Use event export for offline reporting."},
    ]}


async def _admin(session: AsyncSession) -> Dict[str, Any]:
    return {"groups": [
        {"section": "Operations", "items": [{"label": "Integrations", "value": int(await session.scalar(select(func.count(Integration.id))) or 0)}, {"label": "Readiness", "value": "Live"}]},
        {"section": "Inventory", "items": [{"label": "iTwins", "value": int(await session.scalar(select(func.count(ITwin.id))) or 0)}, {"label": "iModels", "value": int(await session.scalar(select(func.count(IModel.id))) or 0)}]},
    ]}


async def _more(session: AsyncSession) -> Dict[str, Any]:
    return {"items": [
        {"label": "Alert Notifications", "value": "Ready"},
        {"label": "Scheduled Maintenance", "value": "Ready"},
        {"label": "Service Status", "value": "Operational"},
        {"label": "App Settings", "value": f"{int(await session.scalar(select(func.count(Integration.id))) or 0)} integrations"},
    ]}


async def _integrations(session: AsyncSession) -> Dict[str, Any]:
    result = await session.execute(select(Integration).order_by(Integration.name))
    rows = result.scalars().all()
    return {"items": [{
        "slug": row.slug,
        "name": row.name,
        "category": row.category,
        "status": row.status,
        "enabled": row.is_enabled,
        "docsUrl": row.docs_url,
    } for row in rows]}


def _page_context(request: Request, tab: str):
    return {"request": request, "user": get_optional_user(request), "app_name": settings.APP_NAME, "active_mobile_tab": tab}


@router.get("/mobile", response_class=HTMLResponse, tags=["Mobile"])
async def mobile_root():
    return RedirectResponse("/mobile/alarms")


@router.get("/mobile/alarms", response_class=HTMLResponse, tags=["Mobile"])
async def alarms_page(request: Request):
    return templates.TemplateResponse("mobile/alarms.html", _page_context(request, "alarms"))


@router.get("/mobile/monitors", response_class=HTMLResponse, tags=["Mobile"])
async def monitors_page(request: Request):
    return templates.TemplateResponse("mobile/monitors.html", _page_context(request, "monitors"))


@router.get("/mobile/reports", response_class=HTMLResponse, tags=["Mobile"])
async def reports_page(request: Request):
    return templates.TemplateResponse("mobile/reports.html", _page_context(request, "reports"))


@router.get("/mobile/admin", response_class=HTMLResponse, tags=["Mobile"])
async def admin_page(request: Request):
    return templates.TemplateResponse("mobile/admin.html", _page_context(request, "admin"))


@router.get("/mobile/more", response_class=HTMLResponse, tags=["Mobile"])
async def more_page(request: Request):
    return templates.TemplateResponse("mobile/more.html", _page_context(request, "more"))


@router.get("/mobile/integrations", response_class=HTMLResponse, tags=["Mobile"])
async def integrations_page(request: Request):
    return templates.TemplateResponse("mobile/integrations.html", _page_context(request, "integrations"))


@router.get("/api/mobile/summary", tags=["Mobile"])
async def summary_api(session: AsyncSession = Depends(get_session)):
    return await _summary(session)


@router.get("/api/mobile/alarms", tags=["Mobile"])
async def alarms_api(session: AsyncSession = Depends(get_session)):
    return await _alarms(session)


@router.get("/api/mobile/monitors", tags=["Mobile"])
async def monitors_api(session: AsyncSession = Depends(get_session)):
    return await _monitors(session)


@router.get("/api/mobile/reports", tags=["Mobile"])
async def reports_api(session: AsyncSession = Depends(get_session)):
    return await _reports(session)


@router.get("/api/mobile/admin-summary", tags=["Mobile"])
async def admin_api(session: AsyncSession = Depends(get_session)):
    return await _admin(session)


@router.get("/api/mobile/more-summary", tags=["Mobile"])
async def more_api(session: AsyncSession = Depends(get_session)):
    return await _more(session)


@router.get("/api/mobile/integrations", tags=["Mobile"])
async def integrations_api(session: AsyncSession = Depends(get_session)):
    return await _integrations(session)
