from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.core.config import settings, is_production
from app.core.security import get_optional_user
from app.db.database import get_session
from app.models.integrations import Integration

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

CHAT_SLUGS = {"smartsupp", "tidio", "tawk-to", "tawkto", "intercom"}
PUSH_SLUGS = {"onesignal", "firebase", "firebase-cloud-messaging"}
ADMIN_ALERT_SLUGS = {"slack", "discord", "telegram", "pagerduty"}
OBSERVABILITY_SLUGS = {"sentry", "datadog"}
DEFAULT_SECRET = "dev-secret-key-change-in-production-min-32-chars"
DEFAULT_ADMIN_PASSWORD = "admin123"


def _has_custom_domain(url: str | None) -> bool:
    if not url:
        return False
    low = url.lower()
    return "replit.dev" not in low and "replit.app" not in low and "vercel.app" not in low


def _has_template(*names: str) -> bool:
    return any((Path("app/templates") / name).exists() for name in names)


async def build_launch_readiness(session: AsyncSession) -> Dict[str, Any]:
    result = await session.execute(select(Integration))
    rows = result.scalars().all()
    connected = {(r.slug or "").strip().lower() for r in rows if r.is_enabled or r.status == "connected"}

    checks: List[Dict[str, Any]] = [
        {
            "label": "Bentley credentials configured",
            "ok": bool(settings.BENTLEY_CLIENT_ID and settings.BENTLEY_CLIENT_SECRET),
            "severity": "blocker",
            "detail": "Set Bentley client ID and client secret for live OAuth and resource access.",
        },
        {
            "label": "Custom public domain configured",
            "ok": _has_custom_domain(settings.PUBLIC_BASE_URL),
            "severity": "blocker" if is_production() else "warning",
            "detail": "Point PUBLIC_BASE_URL to your production domain.",
        },
        {
            "label": "Website chat configured",
            "ok": bool(connected.intersection(CHAT_SLUGS)),
            "severity": "warning",
            "detail": "Connect SmartSupp, Tidio, tawk.to, or another chat provider.",
        },
        {
            "label": "Browser notifications configured",
            "ok": bool(connected.intersection(PUSH_SLUGS)),
            "severity": "warning",
            "detail": "Connect OneSignal or Firebase Cloud Messaging.",
        },
        {
            "label": "Admin alert routing configured",
            "ok": bool(settings.ALERT_SLACK_WEBHOOK or settings.ALERT_DISCORD_WEBHOOK or connected.intersection(ADMIN_ALERT_SLUGS)),
            "severity": "blocker",
            "detail": "Configure Slack/Discord/Telegram/PagerDuty routing for operational alerts.",
        },
        {
            "label": "Observability configured",
            "ok": bool(connected.intersection(OBSERVABILITY_SLUGS)),
            "severity": "warning",
            "detail": "Connect Sentry or Datadog for production monitoring.",
        },
        {
            "label": "Webhook signature verification enabled",
            "ok": bool(settings.WEBHOOK_SECRET) and not settings.SKIP_SIGNATURE_VERIFY,
            "severity": "blocker",
            "detail": "Set WEBHOOK_SECRET and disable SKIP_SIGNATURE_VERIFY in production.",
        },
        {
            "label": "Secure cookies enabled",
            "ok": (not is_production()) or settings.COOKIE_SECURE,
            "severity": "blocker" if is_production() else "warning",
            "detail": "Enable COOKIE_SECURE for HTTPS deployments.",
        },
        {
            "label": "Non-default secret key",
            "ok": bool(settings.SECRET_KEY and settings.SECRET_KEY != DEFAULT_SECRET),
            "severity": "blocker" if is_production() else "warning",
            "detail": "Replace the default SECRET_KEY before launch.",
        },
        {
            "label": "Non-default initial admin password",
            "ok": bool(settings.INITIAL_ADMIN_PASSWORD and settings.INITIAL_ADMIN_PASSWORD != DEFAULT_ADMIN_PASSWORD),
            "severity": "blocker" if is_production() else "warning",
            "detail": "Replace the default admin bootstrap password.",
        },
        {
            "label": "Production database backend",
            "ok": (not is_production()) or settings.DB_IS_POSTGRES,
            "severity": "warning",
            "detail": "Use PostgreSQL instead of SQLite for production deployment.",
        },
        {
            "label": "Privacy page present",
            "ok": _has_template("privacy.html", "privacy_policy.html", "privacy-policy.html"),
            "severity": "warning",
            "detail": "Add a privacy policy page and link it from the footer.",
        },
        {
            "label": "Terms page present",
            "ok": _has_template("terms.html", "terms_of_service.html", "terms-of-service.html"),
            "severity": "warning",
            "detail": "Add terms of service before public release.",
        },
    ]

    blockers = [c for c in checks if (not c["ok"]) and c["severity"] == "blocker"]
    warnings = [c for c in checks if (not c["ok"]) and c["severity"] == "warning"]
    passed = sum(1 for c in checks if c["ok"])
    score = round((passed / len(checks)) * 100) if checks else 100
    overall = "blocked" if blockers else ("in_progress" if warnings else "ready")

    return {
        "overall_status": overall,
        "completion_score": score,
        "summary": {
            "environment": settings.ENVIRONMENT,
            "public_base_url": settings.PUBLIC_BASE_URL,
            "database_backend": "postgres" if settings.DB_IS_POSTGRES else "sqlite",
            "integrations_connected": len(connected),
        },
        "checks": checks,
        "blockers": blockers,
        "warnings": warnings,
        "next_actions": [c["detail"] for c in (blockers + warnings)[:6]],
    }


@router.get("/launch-readiness", response_class=HTMLResponse, tags=["Launch"])
async def launch_readiness_page(request: Request, session: AsyncSession = Depends(get_session)):
    user = get_optional_user(request)
    readiness = await build_launch_readiness(session)
    return templates.TemplateResponse("launch_readiness.html", {
        "request": request,
        "user": user,
        "app_name": settings.APP_NAME,
        "readiness": readiness,
    })


@router.get("/api/launch-readiness", tags=["Launch"])
async def launch_readiness_api(session: AsyncSession = Depends(get_session)):
    return await build_launch_readiness(session)
