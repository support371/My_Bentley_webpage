from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlmodel.ext.asyncio.session import AsyncSession

from app.core.config import settings
from app.core.security import get_optional_user
from app.db.database import get_session
from app.models.module_entities import (
    BillingPlan,
    BrandAsset,
    ClientAccount,
    CloudflareRule,
    CloudflareZone,
    DeploymentProject,
    DomainBinding,
    EnvironmentProfile,
    MarketplaceOffer,
    NewsArticle,
    NewsletterIssue,
    PageSection,
    PaymentGateway,
    PublishRelease,
    ReleaseAuditEvent,
    ServicePortfolio,
    TeamWorkspace,
    WalletAccount,
    WebsitePage,
    WebsiteProject,
)
from app.schemas.control_plane import WorkspaceCreate, WorkspaceRead, WorkspaceUpdate
from app.schemas.module_entities import (
    BillingPlanCreate,
    BillingPlanUpdate,
    BrandAssetCreate,
    BrandAssetUpdate,
    ClientAccountCreate,
    ClientAccountUpdate,
    CloudflareRuleCreate,
    CloudflareRuleUpdate,
    CloudflareZoneCreate,
    CloudflareZoneUpdate,
    DeploymentProjectCreate,
    DeploymentProjectUpdate,
    DomainBindingCreate,
    DomainBindingUpdate,
    EnvironmentProfileCreate,
    EnvironmentProfileUpdate,
    MarketplaceOfferCreate,
    MarketplaceOfferUpdate,
    NewsArticleCreate,
    NewsArticleUpdate,
    NewsletterIssueCreate,
    NewsletterIssueUpdate,
    PageSectionCreate,
    PageSectionUpdate,
    PaymentGatewayCreate,
    PaymentGatewayUpdate,
    PublishReleaseCreate,
    PublishReleaseUpdate,
    ReleaseAuditEventCreate,
    ServicePortfolioCreate,
    ServicePortfolioUpdate,
    TeamWorkspaceCreate,
    TeamWorkspaceUpdate,
    WalletAccountCreate,
    WalletAccountUpdate,
    WebsitePageCreate,
    WebsitePageUpdate,
    WebsiteProjectCreate,
    WebsiteProjectUpdate,
)
from app.services.platform import (
    activate_service_portfolio,
    activate_wallet,
    assign_team_workspace,
    build_module_detail,
    build_module_records,
    create_billing_plan,
    create_brand_asset,
    create_client_account,
    create_cloudflare_rule,
    create_cloudflare_zone,
    create_deployment_project,
    create_domain_binding,
    create_environment_profile,
    create_marketplace_offer,
    create_news_article,
    create_newsletter_issue,
    create_page_section,
    create_payment_gateway,
    create_primary_record,
    create_publish_release,
    create_release_audit_event,
    create_secondary_record,
    create_service_portfolio,
    create_team_workspace,
    create_wallet_account,
    create_website_page,
    create_website_project,
    create_workspace,
    delete_row,
    delete_workspace,
    get_control_module,
    get_control_plane,
    get_row,
    get_workspace,
    list_rows,
    list_workspaces,
    promote_deployment_project,
    publish_news_article,
    publish_release,
    schedule_newsletter_issue,
    summarize_workspaces_by_module,
    toggle_cloudflare_rule,
    update_billing_plan,
    update_brand_asset,
    update_client_account,
    update_cloudflare_rule,
    update_cloudflare_zone,
    update_deployment_project,
    update_domain_binding,
    update_environment_profile,
    update_marketplace_offer,
    update_news_article,
    update_newsletter_issue,
    update_page_section,
    update_payment_gateway,
    update_publish_release,
    update_service_portfolio,
    update_team_workspace,
    update_wallet_account,
    update_website_page,
    update_website_project,
    update_workspace,
)

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _redirect_module(slug: str) -> RedirectResponse:
    return RedirectResponse(url=f"/{slug}", status_code=status.HTTP_303_SEE_OTHER)


async def _render_module_page(slug: str, request: Request, session: AsyncSession):
    user = get_optional_user(request)
    try:
        rows = await list_workspaces(session, module_slug=slug)
        module = build_module_detail(slug, rows)
        module["data_layer"] = await build_module_records(session, slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Module not found") from exc

    return templates.TemplateResponse(
        "platform_module.html",
        {
            "request": request,
            "user": user,
            "app_name": settings.APP_NAME,
            "module": module,
        },
    )


async def _require_row(session: AsyncSession, model: type, row_id: str, detail: str):
    row = await get_row(session, model, row_id)
    if not row:
        raise HTTPException(status_code=404, detail=detail)
    return row


async def _module_alias_feed(session: AsyncSession, slug: str):
    module = build_module_detail(slug, await list_workspaces(session, module_slug=slug))
    module["data_layer"] = await build_module_records(session, slug)
    return module


async def _parse_form_payload(request: Request) -> dict[str, Any]:
    form = await request.form()
    payload: dict[str, Any] = {}
    for key, value in form.items():
        if value in (None, ""):
            continue
        payload[key] = value
    return payload


@router.get("/control-plane", response_class=HTMLResponse, tags=["Platform"])
async def control_plane_view(request: Request, session: AsyncSession = Depends(get_session)):
    user = get_optional_user(request)
    overview = get_control_plane()
    summary = await summarize_workspaces_by_module(session)
    for module in overview["modules"]:
        module["workspace_summary"] = summary.get(module["slug"], {"total": 0, "live": 0, "active": 0, "production": 0})
        module["data_layer"] = await build_module_records(session, module["slug"])
    registry_rows = await list_workspaces(session, limit=12)
    return templates.TemplateResponse(
        "control_plane.html",
        {
            "request": request,
            "user": user,
            "app_name": settings.APP_NAME,
            "overview": overview,
            "registry_rows": registry_rows,
        },
    )


@router.get("/control-plane-registry", response_class=HTMLResponse, tags=["Platform"])
async def control_plane_registry_view(request: Request, module_slug: Optional[str] = None, session: AsyncSession = Depends(get_session)):
    user = get_optional_user(request)
    rows = await list_workspaces(session, module_slug=module_slug, limit=200)
    return templates.TemplateResponse(
        "control_plane_registry.html",
        {
            "request": request,
            "user": user,
            "app_name": settings.APP_NAME,
            "rows": rows,
            "selected_module": module_slug,
        },
    )


@router.get("/api/control-plane", tags=["Platform"])
async def control_plane_feed(session: AsyncSession = Depends(get_session)):
    overview = get_control_plane()
    summary = await summarize_workspaces_by_module(session)
    for module in overview["modules"]:
        module["workspace_summary"] = summary.get(module["slug"], {"total": 0, "live": 0, "active": 0, "production": 0})
        module["data_layer"] = await build_module_records(session, module["slug"])
    return overview


@router.get("/api/control-plane/workspaces", response_model=list[WorkspaceRead], tags=["Platform"])
async def workspaces_feed(module_slug: Optional[str] = None, session: AsyncSession = Depends(get_session)):
    return await list_workspaces(session, module_slug=module_slug)


@router.post("/api/control-plane/workspaces", response_model=WorkspaceRead, status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def create_workspace_feed(payload: WorkspaceCreate, session: AsyncSession = Depends(get_session)):
    try:
        return await create_workspace(session, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/api/control-plane/workspaces/{workspace_id}", response_model=WorkspaceRead, tags=["Platform"])
async def workspace_detail_feed(workspace_id: str, session: AsyncSession = Depends(get_session)):
    workspace = await get_workspace(session, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return workspace


@router.patch("/api/control-plane/workspaces/{workspace_id}", response_model=WorkspaceRead, tags=["Platform"])
async def workspace_update_feed(workspace_id: str, payload: WorkspaceUpdate, session: AsyncSession = Depends(get_session)):
    workspace = await get_workspace(session, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return await update_workspace(session, workspace, payload)


@router.delete("/api/control-plane/workspaces/{workspace_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def workspace_delete_feed(workspace_id: str, session: AsyncSession = Depends(get_session)):
    workspace = await get_workspace(session, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    await delete_workspace(session, workspace)
    return None


@router.get("/api/control-plane/modules/{slug}", tags=["Platform"])
async def control_module_feed(slug: str, session: AsyncSession = Depends(get_session)):
    try:
        rows = await list_workspaces(session, module_slug=slug)
        module = build_module_detail(slug, rows)
        module["data_layer"] = await build_module_records(session, slug)
        return module
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Module not found") from exc


@router.get("/api/control-plane/modules/{slug}/workspaces", response_model=list[WorkspaceRead], tags=["Platform"])
async def module_workspaces_feed(slug: str, session: AsyncSession = Depends(get_session)):
    try:
        get_control_module(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Module not found") from exc
    return await list_workspaces(session, module_slug=slug)


@router.post("/api/control-plane/modules/{slug}/workspaces", response_model=WorkspaceRead, status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def module_workspace_create_feed(slug: str, payload: WorkspaceCreate, session: AsyncSession = Depends(get_session)):
    normalized = payload.model_copy(update={"module_slug": slug}) if hasattr(payload, "model_copy") else payload.copy(update={"module_slug": slug})
    try:
        return await create_workspace(session, normalized)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/control-plane/modules/{slug}/workspaces/create", tags=["Platform"])
async def create_workspace_from_form(
    slug: str,
    name: str = Form(...),
    vertical: str = Form("Cybersecurity"),
    environment: str = Form("preview"),
    priority: str = Form("high"),
    owner_name: str = Form(""),
    summary: str = Form(""),
    session: AsyncSession = Depends(get_session),
):
    payload = WorkspaceCreate(
        module_slug=slug,
        name=name,
        vertical=vertical,
        status="planned",
        environment=environment,
        priority=priority,
        owner_name=owner_name or None,
        summary=summary or None,
    )
    try:
        await create_workspace(session, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return _redirect_module(slug)


@router.post("/control-plane/workspaces/{workspace_id}/status", tags=["Platform"])
async def update_workspace_status_from_form(
    workspace_id: str,
    status_value: str = Form(...),
    redirect_to: str = Form("/control-plane-registry"),
    session: AsyncSession = Depends(get_session),
):
    workspace = await get_workspace(session, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    await update_workspace(session, workspace, WorkspaceUpdate(status=status_value))
    return RedirectResponse(url=redirect_to, status_code=status.HTTP_303_SEE_OTHER)


@router.post("/control-plane/modules/{slug}/records/create", tags=["Platform"])
async def create_primary_record_from_form(slug: str, request: Request, session: AsyncSession = Depends(get_session)):
    payload = await _parse_form_payload(request)
    try:
        await create_primary_record(session, slug, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return _redirect_module(slug)


@router.post("/control-plane/modules/{slug}/records/{record_key}/create", tags=["Platform"])
async def create_secondary_record_from_form(slug: str, record_key: str, request: Request, session: AsyncSession = Depends(get_session)):
    payload = await _parse_form_payload(request)
    try:
        await create_secondary_record(session, slug, record_key, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return _redirect_module(slug)


@router.post("/control-plane/modules/{slug}/actions/{action_key}", tags=["Platform"])
async def run_module_action_from_form(slug: str, action_key: str, request: Request, session: AsyncSession = Depends(get_session)):
    payload = await _parse_form_payload(request)
    if slug == "website-studio" and action_key == "publish-release":
        row = await _require_row(session, PublishRelease, payload["release_id"], "Release not found")
        await publish_release(session, row)
        return _redirect_module(slug)
    if slug == "infrastructure-console" and action_key == "promote-deployment":
        row = await _require_row(session, DeploymentProject, payload["project_id"], "Deployment project not found")
        await promote_deployment_project(session, row, payload.get("target_environment", "production"), payload.get("actor_name"), payload.get("detail"))
        return _redirect_module(slug)
    if slug == "cloudflare-console" and action_key == "toggle-rule":
        row = await _require_row(session, CloudflareRule, payload["rule_id"], "Rule not found")
        await toggle_cloudflare_rule(session, row)
        return _redirect_module(slug)
    if slug == "billing-wallet" and action_key == "activate-wallet":
        row = await _require_row(session, WalletAccount, payload["wallet_id"], "Wallet not found")
        await activate_wallet(session, row)
        return _redirect_module(slug)
    if slug == "marketplace-console" and action_key == "publish-article":
        row = await _require_row(session, NewsArticle, payload["article_id"], "Article not found")
        await publish_news_article(session, row)
        return _redirect_module(slug)
    if slug == "marketplace-console" and action_key == "schedule-newsletter":
        row = await _require_row(session, NewsletterIssue, payload["newsletter_id"], "Newsletter not found")
        await schedule_newsletter_issue(session, row, payload.get("send_window"))
        return _redirect_module(slug)
    if slug == "client-delivery" and action_key == "assign-team":
        row = await _require_row(session, TeamWorkspace, payload["team_id"], "Team not found")
        await assign_team_workspace(session, row, payload.get("client_account_id"))
        return _redirect_module(slug)
    if slug == "client-delivery" and action_key == "activate-portfolio":
        row = await _require_row(session, ServicePortfolio, payload["portfolio_id"], "Portfolio not found")
        await activate_service_portfolio(session, row, payload.get("team_workspace_id"))
        return _redirect_module(slug)
    raise HTTPException(status_code=400, detail="Unsupported action")


@router.get("/website-studio", response_class=HTMLResponse, tags=["Platform"])
async def website_studio_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("website-studio", request, session)


@router.get("/api/website-studio", tags=["Platform"])
async def website_studio_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "website-studio")


@router.get("/infrastructure-console", response_class=HTMLResponse, tags=["Platform"])
async def infrastructure_console_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("infrastructure-console", request, session)


@router.get("/api/infrastructure-console", tags=["Platform"])
async def infrastructure_console_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "infrastructure-console")


@router.get("/cloudflare-console", response_class=HTMLResponse, tags=["Platform"])
async def cloudflare_console_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("cloudflare-console", request, session)


@router.get("/api/cloudflare-console", tags=["Platform"])
async def cloudflare_console_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "cloudflare-console")


@router.get("/billing-wallet", response_class=HTMLResponse, tags=["Platform"])
async def billing_wallet_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("billing-wallet", request, session)


@router.get("/api/billing-wallet", tags=["Platform"])
async def billing_wallet_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "billing-wallet")


@router.get("/marketplace-console", response_class=HTMLResponse, tags=["Platform"])
async def marketplace_console_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("marketplace-console", request, session)


@router.get("/api/marketplace-console", tags=["Platform"])
async def marketplace_console_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "marketplace-console")


@router.get("/client-delivery", response_class=HTMLResponse, tags=["Platform"])
async def client_delivery_view(request: Request, session: AsyncSession = Depends(get_session)):
    return await _render_module_page("client-delivery", request, session)


@router.get("/api/client-delivery", tags=["Platform"])
async def client_delivery_feed(session: AsyncSession = Depends(get_session)):
    return await _module_alias_feed(session, "client-delivery")


# Website Studio APIs
@router.get("/api/website-studio/projects", tags=["Platform"])
async def website_projects_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, WebsiteProject)


@router.post("/api/website-studio/projects", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def website_projects_create_feed(payload: WebsiteProjectCreate, session: AsyncSession = Depends(get_session)):
    return await create_website_project(session, payload)


@router.patch("/api/website-studio/projects/{project_id}", tags=["Platform"])
async def website_projects_update_feed(project_id: str, payload: WebsiteProjectUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WebsiteProject, project_id, "Project not found")
    return await update_website_project(session, row, payload)


@router.delete("/api/website-studio/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def website_projects_delete_feed(project_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WebsiteProject, project_id, "Project not found")
    await delete_row(session, row)
    return None


@router.get("/api/website-studio/pages", tags=["Platform"])
async def website_pages_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, WebsitePage)


@router.post("/api/website-studio/pages", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def website_pages_create_feed(payload: WebsitePageCreate, session: AsyncSession = Depends(get_session)):
    return await create_website_page(session, payload)


@router.patch("/api/website-studio/pages/{page_id}", tags=["Platform"])
async def website_pages_update_feed(page_id: str, payload: WebsitePageUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WebsitePage, page_id, "Page not found")
    return await update_website_page(session, row, payload)


@router.delete("/api/website-studio/pages/{page_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def website_pages_delete_feed(page_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WebsitePage, page_id, "Page not found")
    await delete_row(session, row)
    return None


@router.get("/api/website-studio/sections", tags=["Platform"])
async def website_sections_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, PageSection)


@router.post("/api/website-studio/sections", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def website_sections_create_feed(payload: PageSectionCreate, session: AsyncSession = Depends(get_session)):
    return await create_page_section(session, payload)


@router.patch("/api/website-studio/sections/{section_id}", tags=["Platform"])
async def website_sections_update_feed(section_id: str, payload: PageSectionUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PageSection, section_id, "Section not found")
    return await update_page_section(session, row, payload)


@router.delete("/api/website-studio/sections/{section_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def website_sections_delete_feed(section_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PageSection, section_id, "Section not found")
    await delete_row(session, row)
    return None


@router.get("/api/website-studio/assets", tags=["Platform"])
async def website_assets_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, BrandAsset)


@router.post("/api/website-studio/assets", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def website_assets_create_feed(payload: BrandAssetCreate, session: AsyncSession = Depends(get_session)):
    return await create_brand_asset(session, payload)


@router.patch("/api/website-studio/assets/{asset_id}", tags=["Platform"])
async def website_assets_update_feed(asset_id: str, payload: BrandAssetUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, BrandAsset, asset_id, "Asset not found")
    return await update_brand_asset(session, row, payload)


@router.delete("/api/website-studio/assets/{asset_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def website_assets_delete_feed(asset_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, BrandAsset, asset_id, "Asset not found")
    await delete_row(session, row)
    return None


@router.get("/api/website-studio/releases", tags=["Platform"])
async def website_releases_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, PublishRelease)


@router.post("/api/website-studio/releases", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def website_releases_create_feed(payload: PublishReleaseCreate, session: AsyncSession = Depends(get_session)):
    return await create_publish_release(session, payload)


@router.patch("/api/website-studio/releases/{release_id}", tags=["Platform"])
async def website_releases_update_feed(release_id: str, payload: PublishReleaseUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PublishRelease, release_id, "Release not found")
    return await update_publish_release(session, row, payload)


@router.delete("/api/website-studio/releases/{release_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def website_releases_delete_feed(release_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PublishRelease, release_id, "Release not found")
    await delete_row(session, row)
    return None


@router.post("/api/website-studio/releases/{release_id}/publish", tags=["Platform"])
async def website_releases_publish_feed(release_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PublishRelease, release_id, "Release not found")
    return await publish_release(session, row)


# Infrastructure APIs
@router.get("/api/infrastructure-console/projects", tags=["Platform"])
async def infrastructure_projects_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, DeploymentProject)


@router.post("/api/infrastructure-console/projects", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def infrastructure_projects_create_feed(payload: DeploymentProjectCreate, session: AsyncSession = Depends(get_session)):
    return await create_deployment_project(session, payload)


@router.patch("/api/infrastructure-console/projects/{project_id}", tags=["Platform"])
async def infrastructure_projects_update_feed(project_id: str, payload: DeploymentProjectUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, DeploymentProject, project_id, "Deployment project not found")
    return await update_deployment_project(session, row, payload)


@router.delete("/api/infrastructure-console/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def infrastructure_projects_delete_feed(project_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, DeploymentProject, project_id, "Deployment project not found")
    await delete_row(session, row)
    return None


@router.post("/api/infrastructure-console/projects/{project_id}/promote", tags=["Platform"])
async def infrastructure_projects_promote_feed(
    project_id: str,
    target_environment: str = Form("production"),
    actor_name: str = Form("Platform Ops"),
    detail: str = Form("Release promotion executed."),
    session: AsyncSession = Depends(get_session),
):
    row = await _require_row(session, DeploymentProject, project_id, "Deployment project not found")
    return await promote_deployment_project(session, row, target_environment, actor_name, detail)


@router.get("/api/infrastructure-console/environments", tags=["Platform"])
async def infrastructure_environments_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, EnvironmentProfile)


@router.post("/api/infrastructure-console/environments", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def infrastructure_environments_create_feed(payload: EnvironmentProfileCreate, session: AsyncSession = Depends(get_session)):
    return await create_environment_profile(session, payload)


@router.patch("/api/infrastructure-console/environments/{environment_id}", tags=["Platform"])
async def infrastructure_environments_update_feed(environment_id: str, payload: EnvironmentProfileUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, EnvironmentProfile, environment_id, "Environment not found")
    return await update_environment_profile(session, row, payload)


@router.delete("/api/infrastructure-console/environments/{environment_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def infrastructure_environments_delete_feed(environment_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, EnvironmentProfile, environment_id, "Environment not found")
    await delete_row(session, row)
    return None


@router.get("/api/infrastructure-console/domains", tags=["Platform"])
async def infrastructure_domains_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, DomainBinding)


@router.post("/api/infrastructure-console/domains", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def infrastructure_domains_create_feed(payload: DomainBindingCreate, session: AsyncSession = Depends(get_session)):
    return await create_domain_binding(session, payload)


@router.patch("/api/infrastructure-console/domains/{domain_id}", tags=["Platform"])
async def infrastructure_domains_update_feed(domain_id: str, payload: DomainBindingUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, DomainBinding, domain_id, "Domain binding not found")
    return await update_domain_binding(session, row, payload)


@router.delete("/api/infrastructure-console/domains/{domain_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def infrastructure_domains_delete_feed(domain_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, DomainBinding, domain_id, "Domain binding not found")
    await delete_row(session, row)
    return None


@router.get("/api/infrastructure-console/release-events", tags=["Platform"])
async def infrastructure_release_events_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, ReleaseAuditEvent)


@router.post("/api/infrastructure-console/release-events", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def infrastructure_release_events_create_feed(payload: ReleaseAuditEventCreate, session: AsyncSession = Depends(get_session)):
    return await create_release_audit_event(session, payload)


# Cloudflare APIs
@router.get("/api/cloudflare-console/zones", tags=["Platform"])
async def cloudflare_zones_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, CloudflareZone)


@router.post("/api/cloudflare-console/zones", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def cloudflare_zones_create_feed(payload: CloudflareZoneCreate, session: AsyncSession = Depends(get_session)):
    return await create_cloudflare_zone(session, payload)


@router.patch("/api/cloudflare-console/zones/{zone_id}", tags=["Platform"])
async def cloudflare_zones_update_feed(zone_id: str, payload: CloudflareZoneUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, CloudflareZone, zone_id, "Zone not found")
    return await update_cloudflare_zone(session, row, payload)


@router.delete("/api/cloudflare-console/zones/{zone_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def cloudflare_zones_delete_feed(zone_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, CloudflareZone, zone_id, "Zone not found")
    await delete_row(session, row)
    return None


@router.get("/api/cloudflare-console/rules", tags=["Platform"])
async def cloudflare_rules_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, CloudflareRule)


@router.post("/api/cloudflare-console/rules", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def cloudflare_rules_create_feed(payload: CloudflareRuleCreate, session: AsyncSession = Depends(get_session)):
    return await create_cloudflare_rule(session, payload)


@router.patch("/api/cloudflare-console/rules/{rule_id}", tags=["Platform"])
async def cloudflare_rules_update_feed(rule_id: str, payload: CloudflareRuleUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, CloudflareRule, rule_id, "Rule not found")
    return await update_cloudflare_rule(session, row, payload)


@router.delete("/api/cloudflare-console/rules/{rule_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def cloudflare_rules_delete_feed(rule_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, CloudflareRule, rule_id, "Rule not found")
    await delete_row(session, row)
    return None


@router.post("/api/cloudflare-console/rules/{rule_id}/toggle", tags=["Platform"])
async def cloudflare_rules_toggle_feed(rule_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, CloudflareRule, rule_id, "Rule not found")
    return await toggle_cloudflare_rule(session, row)


# Billing APIs
@router.get("/api/billing-wallet/plans", tags=["Platform"])
async def billing_plans_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, BillingPlan)


@router.post("/api/billing-wallet/plans", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def billing_plans_create_feed(payload: BillingPlanCreate, session: AsyncSession = Depends(get_session)):
    return await create_billing_plan(session, payload)


@router.patch("/api/billing-wallet/plans/{plan_id}", tags=["Platform"])
async def billing_plans_update_feed(plan_id: str, payload: BillingPlanUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, BillingPlan, plan_id, "Plan not found")
    return await update_billing_plan(session, row, payload)


@router.delete("/api/billing-wallet/plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def billing_plans_delete_feed(plan_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, BillingPlan, plan_id, "Plan not found")
    await delete_row(session, row)
    return None


@router.get("/api/billing-wallet/gateways", tags=["Platform"])
async def billing_gateways_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, PaymentGateway)


@router.post("/api/billing-wallet/gateways", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def billing_gateways_create_feed(payload: PaymentGatewayCreate, session: AsyncSession = Depends(get_session)):
    return await create_payment_gateway(session, payload)


@router.patch("/api/billing-wallet/gateways/{gateway_id}", tags=["Platform"])
async def billing_gateways_update_feed(gateway_id: str, payload: PaymentGatewayUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PaymentGateway, gateway_id, "Gateway not found")
    return await update_payment_gateway(session, row, payload)


@router.delete("/api/billing-wallet/gateways/{gateway_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def billing_gateways_delete_feed(gateway_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, PaymentGateway, gateway_id, "Gateway not found")
    await delete_row(session, row)
    return None


@router.get("/api/billing-wallet/wallets", tags=["Platform"])
async def billing_wallets_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, WalletAccount)


@router.post("/api/billing-wallet/wallets", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def billing_wallets_create_feed(payload: WalletAccountCreate, session: AsyncSession = Depends(get_session)):
    return await create_wallet_account(session, payload)


@router.patch("/api/billing-wallet/wallets/{wallet_id}", tags=["Platform"])
async def billing_wallets_update_feed(wallet_id: str, payload: WalletAccountUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WalletAccount, wallet_id, "Wallet not found")
    return await update_wallet_account(session, row, payload)


@router.delete("/api/billing-wallet/wallets/{wallet_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def billing_wallets_delete_feed(wallet_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WalletAccount, wallet_id, "Wallet not found")
    await delete_row(session, row)
    return None


@router.post("/api/billing-wallet/wallets/{wallet_id}/activate", tags=["Platform"])
async def billing_wallets_activate_feed(wallet_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, WalletAccount, wallet_id, "Wallet not found")
    return await activate_wallet(session, row)


# Marketplace APIs
@router.get("/api/marketplace-console/offers", tags=["Platform"])
async def marketplace_offers_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, MarketplaceOffer)


@router.post("/api/marketplace-console/offers", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def marketplace_offers_create_feed(payload: MarketplaceOfferCreate, session: AsyncSession = Depends(get_session)):
    return await create_marketplace_offer(session, payload)


@router.patch("/api/marketplace-console/offers/{offer_id}", tags=["Platform"])
async def marketplace_offers_update_feed(offer_id: str, payload: MarketplaceOfferUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, MarketplaceOffer, offer_id, "Offer not found")
    return await update_marketplace_offer(session, row, payload)


@router.delete("/api/marketplace-console/offers/{offer_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def marketplace_offers_delete_feed(offer_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, MarketplaceOffer, offer_id, "Offer not found")
    await delete_row(session, row)
    return None


@router.get("/api/marketplace-console/articles", tags=["Platform"])
async def marketplace_articles_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, NewsArticle)


@router.post("/api/marketplace-console/articles", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def marketplace_articles_create_feed(payload: NewsArticleCreate, session: AsyncSession = Depends(get_session)):
    return await create_news_article(session, payload)


@router.patch("/api/marketplace-console/articles/{article_id}", tags=["Platform"])
async def marketplace_articles_update_feed(article_id: str, payload: NewsArticleUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsArticle, article_id, "Article not found")
    return await update_news_article(session, row, payload)


@router.delete("/api/marketplace-console/articles/{article_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def marketplace_articles_delete_feed(article_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsArticle, article_id, "Article not found")
    await delete_row(session, row)
    return None


@router.post("/api/marketplace-console/articles/{article_id}/publish", tags=["Platform"])
async def marketplace_articles_publish_feed(article_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsArticle, article_id, "Article not found")
    return await publish_news_article(session, row)


@router.get("/api/marketplace-console/newsletters", tags=["Platform"])
async def marketplace_newsletters_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, NewsletterIssue)


@router.post("/api/marketplace-console/newsletters", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def marketplace_newsletters_create_feed(payload: NewsletterIssueCreate, session: AsyncSession = Depends(get_session)):
    return await create_newsletter_issue(session, payload)


@router.patch("/api/marketplace-console/newsletters/{newsletter_id}", tags=["Platform"])
async def marketplace_newsletters_update_feed(newsletter_id: str, payload: NewsletterIssueUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsletterIssue, newsletter_id, "Newsletter not found")
    return await update_newsletter_issue(session, row, payload)


@router.delete("/api/marketplace-console/newsletters/{newsletter_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def marketplace_newsletters_delete_feed(newsletter_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsletterIssue, newsletter_id, "Newsletter not found")
    await delete_row(session, row)
    return None


@router.post("/api/marketplace-console/newsletters/{newsletter_id}/schedule", tags=["Platform"])
async def marketplace_newsletters_schedule_feed(newsletter_id: str, send_window: str = Form("09:00 ET"), session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, NewsletterIssue, newsletter_id, "Newsletter not found")
    return await schedule_newsletter_issue(session, row, send_window)


# Client Delivery APIs
@router.get("/api/client-delivery/clients", tags=["Platform"])
async def client_accounts_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, ClientAccount)


@router.post("/api/client-delivery/clients", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def client_accounts_create_feed(payload: ClientAccountCreate, session: AsyncSession = Depends(get_session)):
    return await create_client_account(session, payload)


@router.patch("/api/client-delivery/clients/{client_id}", tags=["Platform"])
async def client_accounts_update_feed(client_id: str, payload: ClientAccountUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, ClientAccount, client_id, "Client not found")
    return await update_client_account(session, row, payload)


@router.delete("/api/client-delivery/clients/{client_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def client_accounts_delete_feed(client_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, ClientAccount, client_id, "Client not found")
    await delete_row(session, row)
    return None


@router.get("/api/client-delivery/teams", tags=["Platform"])
async def team_workspaces_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, TeamWorkspace)


@router.post("/api/client-delivery/teams", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def team_workspaces_create_feed(payload: TeamWorkspaceCreate, session: AsyncSession = Depends(get_session)):
    return await create_team_workspace(session, payload)


@router.patch("/api/client-delivery/teams/{team_id}", tags=["Platform"])
async def team_workspaces_update_feed(team_id: str, payload: TeamWorkspaceUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, TeamWorkspace, team_id, "Team not found")
    return await update_team_workspace(session, row, payload)


@router.delete("/api/client-delivery/teams/{team_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def team_workspaces_delete_feed(team_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, TeamWorkspace, team_id, "Team not found")
    await delete_row(session, row)
    return None


@router.post("/api/client-delivery/teams/{team_id}/assign-client", tags=["Platform"])
async def team_workspaces_assign_feed(team_id: str, client_account_id: Optional[str] = Form(None), session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, TeamWorkspace, team_id, "Team not found")
    return await assign_team_workspace(session, row, client_account_id)


@router.get("/api/client-delivery/portfolios", tags=["Platform"])
async def service_portfolios_feed(session: AsyncSession = Depends(get_session)):
    return await list_rows(session, ServicePortfolio)


@router.post("/api/client-delivery/portfolios", status_code=status.HTTP_201_CREATED, tags=["Platform"])
async def service_portfolios_create_feed(payload: ServicePortfolioCreate, session: AsyncSession = Depends(get_session)):
    return await create_service_portfolio(session, payload)


@router.patch("/api/client-delivery/portfolios/{portfolio_id}", tags=["Platform"])
async def service_portfolios_update_feed(portfolio_id: str, payload: ServicePortfolioUpdate, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, ServicePortfolio, portfolio_id, "Portfolio not found")
    return await update_service_portfolio(session, row, payload)


@router.delete("/api/client-delivery/portfolios/{portfolio_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Platform"])
async def service_portfolios_delete_feed(portfolio_id: str, session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, ServicePortfolio, portfolio_id, "Portfolio not found")
    await delete_row(session, row)
    return None


@router.post("/api/client-delivery/portfolios/{portfolio_id}/activate", tags=["Platform"])
async def service_portfolios_activate_feed(portfolio_id: str, team_workspace_id: Optional[str] = Form(None), session: AsyncSession = Depends(get_session)):
    row = await _require_row(session, ServicePortfolio, portfolio_id, "Portfolio not found")
    return await activate_service_portfolio(session, row, team_workspace_id)
