from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.core.config import settings
from app.core.security import get_optional_user
from app.services.platform import get_universal_launch_flow

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/platform-flow", response_class=HTMLResponse, tags=["Platform"])
async def platform_flow_view(request: Request):
    user = get_optional_user(request)
    flow = get_universal_launch_flow()
    return templates.TemplateResponse(
        "platform_flow.html",
        {
            "request": request,
            "user": user,
            "app_name": settings.APP_NAME,
            "flow": flow,
        },
    )


@router.get("/api/platform-flow", tags=["Platform"])
async def platform_flow_feed():
    return get_universal_launch_flow()
