from __future__ import annotations

from datetime import datetime
from typing import Any, Type

from sqlalchemy import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.models.module_entities import (
    BillingPlan,
    BrandAsset,
    ClientAccount,
    CloudflareRule,
    CloudflareZone,
    DeploymentProject,
    DomainBinding,
    EnvironmentProfile,
    MarketplaceOffer,
    NewsArticle,
    NewsletterIssue,
    PageSection,
    PaymentGateway,
    PublishRelease,
    ReleaseAuditEvent,
    ServicePortfolio,
    TeamWorkspace,
    WalletAccount,
    WebsitePage,
    WebsiteProject,
)
from app.schemas.module_entities import (
    BillingPlanCreate,
    BillingPlanUpdate,
    BrandAssetCreate,
    BrandAssetUpdate,
    ClientAccountCreate,
    ClientAccountUpdate,
    CloudflareRuleCreate,
    CloudflareRuleUpdate,
    CloudflareZoneCreate,
    CloudflareZoneUpdate,
    DeploymentProjectCreate,
    DeploymentProjectUpdate,
    DomainBindingCreate,
    DomainBindingUpdate,
    EnvironmentProfileCreate,
    EnvironmentProfileUpdate,
    MarketplaceOfferCreate,
    MarketplaceOfferUpdate,
    NewsArticleCreate,
    NewsArticleUpdate,
    NewsletterIssueCreate,
    NewsletterIssueUpdate,
    PageSectionCreate,
    PageSectionUpdate,
    PaymentGatewayCreate,
    PaymentGatewayUpdate,
    PublishReleaseCreate,
    PublishReleaseUpdate,
    ReleaseAuditEventCreate,
    ServicePortfolioCreate,
    ServicePortfolioUpdate,
    TeamWorkspaceCreate,
    TeamWorkspaceUpdate,
    WalletAccountCreate,
    WalletAccountUpdate,
    WebsitePageCreate,
    WebsitePageUpdate,
    WebsiteProjectCreate,
    WebsiteProjectUpdate,
)


def _normalize_text(value: Any, lowercase: bool = False, uppercase: bool = False, slug: bool = False) -> Any:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if slug:
        value = value.lower().replace(" ", "-")
    elif lowercase:
        value = value.lower()
    elif uppercase:
        value = value.upper()
    return value


def _normalize_payload(data: dict[str, Any], lowercase_fields: set[str] | None = None, uppercase_fields: set[str] | None = None, slug_fields: set[str] | None = None) -> dict[str, Any]:
    lowercase_fields = lowercase_fields or set()
    uppercase_fields = uppercase_fields or set()
    slug_fields = slug_fields or set()
    normalized: dict[str, Any] = {}
    for key, value in data.items():
        if key in slug_fields:
            normalized[key] = _normalize_text(value, slug=True)
        elif key in lowercase_fields:
            normalized[key] = _normalize_text(value, lowercase=True)
        elif key in uppercase_fields:
            normalized[key] = _normalize_text(value, uppercase=True)
        else:
            normalized[key] = _normalize_text(value)
    return normalized


async def list_rows(session: AsyncSession, model: type, limit: int = 20) -> list[Any]:
    order_field = getattr(model, "created_at", None)
    stmt = select(model)
    if order_field is not None:
        stmt = stmt.order_by(order_field.desc())
    if limit:
        stmt = stmt.limit(limit)
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def get_row(session: AsyncSession, model: type, row_id: str) -> Any | None:
    result = await session.execute(select(model).where(model.id == row_id))
    return result.scalars().first()


async def create_row(session: AsyncSession, model: type, data: dict[str, Any]) -> Any:
    row = model(**data)
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def update_row(session: AsyncSession, row: Any, updates: dict[str, Any]) -> Any:
    for key, value in updates.items():
        setattr(row, key, value)
    if hasattr(row, "updated_at"):
        setattr(row, "updated_at", datetime.utcnow())
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def delete_row(session: AsyncSession, row: Any) -> None:
    await session.delete(row)
    await session.commit()


async def create_website_project(session: AsyncSession, payload: WebsiteProjectCreate) -> WebsiteProject:
    return await create_row(
        session,
        WebsiteProject,
        _normalize_payload(payload.model_dump(), lowercase_fields={"status"}, slug_fields={"slug"}),
    )


async def update_website_project(session: AsyncSession, row: WebsiteProject, payload: WebsiteProjectUpdate) -> WebsiteProject:
    return await update_row(
        session,
        row,
        _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}, slug_fields={"slug"}),
    )


async def create_website_page(session: AsyncSession, payload: WebsitePageCreate) -> WebsitePage:
    return await create_row(
        session,
        WebsitePage,
        _normalize_payload(payload.model_dump(), lowercase_fields={"status"}, slug_fields={"slug"}),
    )


async def update_website_page(session: AsyncSession, row: WebsitePage, payload: WebsitePageUpdate) -> WebsitePage:
    return await update_row(
        session,
        row,
        _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}, slug_fields={"slug"}),
    )


async def create_page_section(session: AsyncSession, payload: PageSectionCreate) -> PageSection:
    return await create_row(session, PageSection, _normalize_payload(payload.model_dump()))


async def update_page_section(session: AsyncSession, row: PageSection, payload: PageSectionUpdate) -> PageSection:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True)))


async def create_brand_asset(session: AsyncSession, payload: BrandAssetCreate) -> BrandAsset:
    return await create_row(session, BrandAsset, _normalize_payload(payload.model_dump()))


async def update_brand_asset(session: AsyncSession, row: BrandAsset, payload: BrandAssetUpdate) -> BrandAsset:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True)))


async def create_publish_release(session: AsyncSession, payload: PublishReleaseCreate) -> PublishRelease:
    return await create_row(session, PublishRelease, _normalize_payload(payload.model_dump(), lowercase_fields={"environment", "status"}))


async def update_publish_release(session: AsyncSession, row: PublishRelease, payload: PublishReleaseUpdate) -> PublishRelease:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"environment", "status"}))


async def publish_release(session: AsyncSession, row: PublishRelease) -> PublishRelease:
    row.status = "published"
    row.published_at = datetime.utcnow()
    row.updated_at = datetime.utcnow()
    project = await get_row(session, WebsiteProject, row.project_id)
    if project:
        project.status = "live"
        project.updated_at = datetime.utcnow()
        session.add(project)
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_deployment_project(session: AsyncSession, payload: DeploymentProjectCreate) -> DeploymentProject:
    return await create_row(session, DeploymentProject, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_deployment_project(session: AsyncSession, row: DeploymentProject, payload: DeploymentProjectUpdate) -> DeploymentProject:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def create_environment_profile(session: AsyncSession, payload: EnvironmentProfileCreate) -> EnvironmentProfile:
    return await create_row(session, EnvironmentProfile, _normalize_payload(payload.model_dump(), lowercase_fields={"stage", "deployment_status", "health_status"}))


async def update_environment_profile(session: AsyncSession, row: EnvironmentProfile, payload: EnvironmentProfileUpdate) -> EnvironmentProfile:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"stage", "deployment_status", "health_status"}))


async def create_domain_binding(session: AsyncSession, payload: DomainBindingCreate) -> DomainBinding:
    return await create_row(session, DomainBinding, _normalize_payload(payload.model_dump(), lowercase_fields={"ssl_mode", "status"}))


async def update_domain_binding(session: AsyncSession, row: DomainBinding, payload: DomainBindingUpdate) -> DomainBinding:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"ssl_mode", "status"}))


async def create_release_audit_event(session: AsyncSession, payload: ReleaseAuditEventCreate) -> ReleaseAuditEvent:
    return await create_row(session, ReleaseAuditEvent, _normalize_payload(payload.model_dump()))


async def promote_deployment_project(
    session: AsyncSession,
    project: DeploymentProject,
    target_environment: str,
    actor_name: str | None,
    detail: str | None,
) -> ReleaseAuditEvent:
    project.status = "active"
    project.updated_at = datetime.utcnow()
    session.add(project)
    result = await session.execute(
        select(EnvironmentProfile).where(
            EnvironmentProfile.deployment_project_id == project.id,
            EnvironmentProfile.name == target_environment,
        )
    )
    env = result.scalars().first()
    if env:
        env.deployment_status = "healthy"
        env.health_status = "green"
        env.updated_at = datetime.utcnow()
        session.add(env)
    event = ReleaseAuditEvent(
        deployment_project_id=project.id,
        event_type="promotion",
        actor_name=actor_name or "Platform Ops",
        target_environment=target_environment,
        detail=detail or f"Project promoted to {target_environment}.",
    )
    session.add(event)
    await session.commit()
    await session.refresh(event)
    return event


async def create_cloudflare_zone(session: AsyncSession, payload: CloudflareZoneCreate) -> CloudflareZone:
    return await create_row(session, CloudflareZone, _normalize_payload(payload.model_dump(), lowercase_fields={"status", "ssl_mode", "waf_mode", "cache_strategy"}))


async def update_cloudflare_zone(session: AsyncSession, row: CloudflareZone, payload: CloudflareZoneUpdate) -> CloudflareZone:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status", "ssl_mode", "waf_mode", "cache_strategy"}))


async def create_cloudflare_rule(session: AsyncSession, payload: CloudflareRuleCreate) -> CloudflareRule:
    return await create_row(session, CloudflareRule, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_cloudflare_rule(session: AsyncSession, row: CloudflareRule, payload: CloudflareRuleUpdate) -> CloudflareRule:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def toggle_cloudflare_rule(session: AsyncSession, row: CloudflareRule) -> CloudflareRule:
    row.status = "disabled" if row.status == "active" else "active"
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_billing_plan(session: AsyncSession, payload: BillingPlanCreate) -> BillingPlan:
    return await create_row(session, BillingPlan, _normalize_payload(payload.model_dump(), lowercase_fields={"cadence", "status"}, uppercase_fields={"currency"}))


async def update_billing_plan(session: AsyncSession, row: BillingPlan, payload: BillingPlanUpdate) -> BillingPlan:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"cadence", "status"}, uppercase_fields={"currency"}))


async def create_payment_gateway(session: AsyncSession, payload: PaymentGatewayCreate) -> PaymentGateway:
    return await create_row(session, PaymentGateway, _normalize_payload(payload.model_dump(), lowercase_fields={"status", "webhook_status"}))


async def update_payment_gateway(session: AsyncSession, row: PaymentGateway, payload: PaymentGatewayUpdate) -> PaymentGateway:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status", "webhook_status"}))


async def create_wallet_account(session: AsyncSession, payload: WalletAccountCreate) -> WalletAccount:
    return await create_row(session, WalletAccount, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_wallet_account(session: AsyncSession, row: WalletAccount, payload: WalletAccountUpdate) -> WalletAccount:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def activate_wallet(session: AsyncSession, row: WalletAccount) -> WalletAccount:
    row.status = "active"
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_marketplace_offer(session: AsyncSession, payload: MarketplaceOfferCreate) -> MarketplaceOffer:
    return await create_row(session, MarketplaceOffer, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_marketplace_offer(session: AsyncSession, row: MarketplaceOffer, payload: MarketplaceOfferUpdate) -> MarketplaceOffer:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def create_news_article(session: AsyncSession, payload: NewsArticleCreate) -> NewsArticle:
    return await create_row(session, NewsArticle, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}, slug_fields={"slug"}))


async def update_news_article(session: AsyncSession, row: NewsArticle, payload: NewsArticleUpdate) -> NewsArticle:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}, slug_fields={"slug"}))


async def publish_news_article(session: AsyncSession, row: NewsArticle) -> NewsArticle:
    row.status = "published"
    row.published_at = datetime.utcnow()
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_newsletter_issue(session: AsyncSession, payload: NewsletterIssueCreate) -> NewsletterIssue:
    return await create_row(session, NewsletterIssue, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_newsletter_issue(session: AsyncSession, row: NewsletterIssue, payload: NewsletterIssueUpdate) -> NewsletterIssue:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def schedule_newsletter_issue(session: AsyncSession, row: NewsletterIssue, send_window: str | None = None) -> NewsletterIssue:
    row.status = "scheduled"
    if send_window:
        row.send_window = send_window
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_client_account(session: AsyncSession, payload: ClientAccountCreate) -> ClientAccount:
    return await create_row(session, ClientAccount, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_client_account(session: AsyncSession, row: ClientAccount, payload: ClientAccountUpdate) -> ClientAccount:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def create_team_workspace(session: AsyncSession, payload: TeamWorkspaceCreate) -> TeamWorkspace:
    return await create_row(session, TeamWorkspace, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_team_workspace(session: AsyncSession, row: TeamWorkspace, payload: TeamWorkspaceUpdate) -> TeamWorkspace:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def assign_team_workspace(session: AsyncSession, row: TeamWorkspace, client_account_id: str | None) -> TeamWorkspace:
    row.client_account_id = client_account_id
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


async def create_service_portfolio(session: AsyncSession, payload: ServicePortfolioCreate) -> ServicePortfolio:
    return await create_row(session, ServicePortfolio, _normalize_payload(payload.model_dump(), lowercase_fields={"status"}))


async def update_service_portfolio(session: AsyncSession, row: ServicePortfolio, payload: ServicePortfolioUpdate) -> ServicePortfolio:
    return await update_row(session, row, _normalize_payload(payload.model_dump(exclude_none=True), lowercase_fields={"status"}))


async def activate_service_portfolio(session: AsyncSession, row: ServicePortfolio, team_workspace_id: str | None = None) -> ServicePortfolio:
    row.status = "active"
    if team_workspace_id is not None:
        row.team_workspace_id = team_workspace_id
    row.updated_at = datetime.utcnow()
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return row


def _serialize_card(row: Any, title_field: str, chips: list[str], summary_field: str | None = None, extra_fields: list[str] | None = None) -> dict[str, Any]:
    card = {
        "id": getattr(row, "id"),
        "title": getattr(row, title_field),
        "chips": [str(getattr(row, attr)) for attr in chips if getattr(row, attr, None) not in (None, "")],
        "summary": getattr(row, summary_field) if summary_field else None,
    }
    if extra_fields:
        card["fields"] = {name: getattr(row, name, None) for name in extra_fields}
    created_at = getattr(row, "created_at", None)
    if created_at:
        card["created_at"] = created_at.isoformat() + "Z"
    return card


def _form(title: str, action: str, fields: list[dict[str, Any]]) -> dict[str, Any]:
    return {"title": title, "action": action, "fields": fields}


def _workflow(title: str, action: str, fields: list[dict[str, Any]]) -> dict[str, Any]:
    return {"title": title, "action": action, "fields": fields}


async def build_module_records(session: AsyncSession, module_slug: str) -> dict[str, Any]:
    if module_slug == "website-studio":
        projects = await list_rows(session, WebsiteProject, 8)
        pages = await list_rows(session, WebsitePage, 8)
        sections = await list_rows(session, PageSection, 8)
        assets = await list_rows(session, BrandAsset, 8)
        releases = await list_rows(session, PublishRelease, 8)
        project_options = [{"value": row.id, "label": row.name} for row in projects]
        page_options = [{"value": row.id, "label": row.title} for row in pages]
        release_options = [{"value": row.id, "label": row.version_label} for row in releases]
        return {
            "summary_tiles": [
                {"label": "Projects", "value": len(projects)},
                {"label": "Pages", "value": len(pages)},
                {"label": "Sections", "value": len(sections)},
                {"label": "Releases", "value": len(releases)},
            ],
            "panels": [
                {"title": "Website projects", "endpoint": "/api/website-studio/projects", "items": [_serialize_card(r, "name", ["vertical", "status", "primary_domain"], "summary") for r in projects]},
                {"title": "Page inventory", "endpoint": "/api/website-studio/pages", "items": [_serialize_card(r, "title", ["page_type", "status", "slug"], extra_fields=["project_id"]) for r in pages]},
                {"title": "Section schema", "endpoint": "/api/website-studio/sections", "items": [_serialize_card(r, "title", ["component_type", "section_key"], extra_fields=["page_id"]) for r in sections]},
                {"title": "Brand assets", "endpoint": "/api/website-studio/assets", "items": [_serialize_card(r, "name", ["asset_type", "usage_context"], extra_fields=["project_id"]) for r in assets]},
                {"title": "Publish releases", "endpoint": "/api/website-studio/releases", "items": [_serialize_card(r, "version_label", ["environment", "status"], "notes", extra_fields=["project_id"]) for r in releases]},
            ],
            "form": _form(
                "Create website project",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Project name", "type": "text", "placeholder": "Corporate launch site"},
                    {"name": "slug", "label": "Project slug", "type": "text", "placeholder": "corporate-launch-site"},
                    {"name": "vertical", "label": "Vertical", "type": "text", "placeholder": "Cybersecurity"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "draft"},
                    {"name": "primary_domain", "label": "Primary domain", "type": "text", "placeholder": "launch.example.com"},
                    {"name": "owner_name", "label": "Owner", "type": "text", "placeholder": "Platform lead"},
                    {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Describe the public site, service coverage, and publish target."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create website page",
                    f"/control-plane/modules/{module_slug}/records/pages/create",
                    [
                        {"name": "project_id", "label": "Project", "type": "select", "options": project_options},
                        {"name": "title", "label": "Title", "type": "text", "placeholder": "Developer Tools"},
                        {"name": "slug", "label": "Slug", "type": "text", "placeholder": "developer-tools"},
                        {"name": "page_type", "label": "Page type", "type": "text", "placeholder": "service"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "draft"},
                        {"name": "hero_title", "label": "Hero title", "type": "text", "placeholder": "High-end front-end and back-end delivery"},
                        {"name": "seo_title", "label": "SEO title", "type": "text", "placeholder": "Developer Services | GEM"},
                        {"name": "seo_description", "label": "SEO description", "type": "textarea", "placeholder": "Full-stack development, deployment, automation, and production support."},
                    ],
                ),
                _form(
                    "Create page section",
                    f"/control-plane/modules/{module_slug}/records/sections/create",
                    [
                        {"name": "page_id", "label": "Page", "type": "select", "options": page_options},
                        {"name": "section_key", "label": "Section key", "type": "text", "placeholder": "hero"},
                        {"name": "title", "label": "Section title", "type": "text", "placeholder": "Hero"},
                        {"name": "component_type", "label": "Component type", "type": "text", "placeholder": "hero"},
                        {"name": "body", "label": "Body", "type": "textarea", "placeholder": "Primary message, proof points, and CTA copy."},
                    ],
                ),
                _form(
                    "Create publish release",
                    f"/control-plane/modules/{module_slug}/records/releases/create",
                    [
                        {"name": "project_id", "label": "Project", "type": "select", "options": project_options},
                        {"name": "version_label", "label": "Version", "type": "text", "placeholder": "v1.0"},
                        {"name": "environment", "label": "Environment", "type": "text", "placeholder": "preview"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "pending"},
                        {"name": "notes", "label": "Notes", "type": "textarea", "placeholder": "Final publish checklist pending approval."},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Publish release",
                    f"/control-plane/modules/{module_slug}/actions/publish-release",
                    [{"name": "release_id", "label": "Release", "type": "select", "options": release_options}],
                )
            ],
        }

    if module_slug == "infrastructure-console":
        projects = await list_rows(session, DeploymentProject, 8)
        environments = await list_rows(session, EnvironmentProfile, 8)
        domains = await list_rows(session, DomainBinding, 8)
        events = await list_rows(session, ReleaseAuditEvent, 8)
        project_options = [{"value": row.id, "label": row.name} for row in projects]
        return {
            "summary_tiles": [
                {"label": "Deployments", "value": len(projects)},
                {"label": "Environments", "value": len(environments)},
                {"label": "Domains", "value": len(domains)},
                {"label": "Release events", "value": len(events)},
            ],
            "panels": [
                {"title": "Deployment projects", "endpoint": "/api/infrastructure-console/projects", "items": [_serialize_card(r, "name", ["provider", "target_stack", "status", "primary_domain"], "summary") for r in projects]},
                {"title": "Environment profiles", "endpoint": "/api/infrastructure-console/environments", "items": [_serialize_card(r, "name", ["stage", "deployment_status", "health_status", "region"], extra_fields=["deployment_project_id"]) for r in environments]},
                {"title": "Domain bindings", "endpoint": "/api/infrastructure-console/domains", "items": [_serialize_card(r, "hostname", ["dns_provider", "ssl_mode", "status"], extra_fields=["deployment_project_id"]) for r in domains]},
                {"title": "Release audit", "endpoint": "/api/infrastructure-console/release-events", "items": [_serialize_card(r, "event_type", ["target_environment", "actor_name"], "detail", extra_fields=["deployment_project_id"]) for r in events]},
            ],
            "form": _form(
                "Create deployment project",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Deployment name", "type": "text", "placeholder": "Primary production stack"},
                    {"name": "provider", "label": "Provider", "type": "text", "placeholder": "Cloudflare"},
                    {"name": "target_stack", "label": "Target stack", "type": "text", "placeholder": "FastAPI + Edge"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "planned"},
                    {"name": "primary_domain", "label": "Primary domain", "type": "text", "placeholder": "app.example.com"},
                    {"name": "repo_url", "label": "Repository URL", "type": "text", "placeholder": "https://github.com/org/repo"},
                    {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Describe environments, runtime controls, and deployment responsibility."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create environment profile",
                    f"/control-plane/modules/{module_slug}/records/environments/create",
                    [
                        {"name": "deployment_project_id", "label": "Deployment", "type": "select", "options": project_options},
                        {"name": "name", "label": "Environment name", "type": "text", "placeholder": "staging"},
                        {"name": "stage", "label": "Stage", "type": "text", "placeholder": "staging"},
                        {"name": "app_url", "label": "App URL", "type": "text", "placeholder": "https://staging.example.com"},
                        {"name": "deployment_status", "label": "Deployment status", "type": "text", "placeholder": "pending"},
                        {"name": "health_status", "label": "Health status", "type": "text", "placeholder": "yellow"},
                        {"name": "region", "label": "Region", "type": "text", "placeholder": "global"},
                    ],
                ),
                _form(
                    "Create domain binding",
                    f"/control-plane/modules/{module_slug}/records/domains/create",
                    [
                        {"name": "deployment_project_id", "label": "Deployment", "type": "select", "options": project_options},
                        {"name": "hostname", "label": "Hostname", "type": "text", "placeholder": "app.example.com"},
                        {"name": "dns_provider", "label": "DNS provider", "type": "text", "placeholder": "Cloudflare"},
                        {"name": "ssl_mode", "label": "SSL mode", "type": "text", "placeholder": "strict"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "pending"},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Promote deployment",
                    f"/control-plane/modules/{module_slug}/actions/promote-deployment",
                    [
                        {"name": "project_id", "label": "Deployment", "type": "select", "options": project_options},
                        {"name": "target_environment", "label": "Target environment", "type": "text", "placeholder": "production"},
                        {"name": "actor_name", "label": "Actor", "type": "text", "placeholder": "Platform Ops"},
                        {"name": "detail", "label": "Detail", "type": "textarea", "placeholder": "All checks passed. Promote to production."},
                    ],
                )
            ],
        }

    if module_slug == "cloudflare-console":
        zones = await list_rows(session, CloudflareZone, 8)
        rules = await list_rows(session, CloudflareRule, 8)
        zone_options = [{"value": row.id, "label": row.name} for row in zones]
        rule_options = [{"value": row.id, "label": row.rule_name} for row in rules]
        return {
            "summary_tiles": [
                {"label": "Zones", "value": len(zones)},
                {"label": "Rules", "value": len(rules)},
                {"label": "Managed WAF", "value": sum(1 for row in zones if row.waf_mode == "managed")},
                {"label": "Strict SSL", "value": sum(1 for row in zones if row.ssl_mode == "strict")},
            ],
            "panels": [
                {"title": "Cloudflare zones", "endpoint": "/api/cloudflare-console/zones", "items": [_serialize_card(r, "name", ["zone_name", "status", "ssl_mode", "waf_mode"], "notes") for r in zones]},
                {"title": "Security rules", "endpoint": "/api/cloudflare-console/rules", "items": [_serialize_card(r, "rule_name", ["rule_type", "action", "status"], extra_fields=["zone_id", "priority"]) for r in rules]},
            ],
            "form": _form(
                "Create Cloudflare zone",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Zone label", "type": "text", "placeholder": "Corporate zone"},
                    {"name": "zone_name", "label": "Zone name", "type": "text", "placeholder": "example.com"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "active"},
                    {"name": "ssl_mode", "label": "SSL mode", "type": "text", "placeholder": "strict"},
                    {"name": "waf_mode", "label": "WAF mode", "type": "text", "placeholder": "managed"},
                    {"name": "cache_strategy", "label": "Cache strategy", "type": "text", "placeholder": "standard"},
                    {"name": "notes", "label": "Notes", "type": "textarea", "placeholder": "Describe rate limits, rules, and incident posture."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create Cloudflare rule",
                    f"/control-plane/modules/{module_slug}/records/rules/create",
                    [
                        {"name": "zone_id", "label": "Zone", "type": "select", "options": zone_options},
                        {"name": "rule_name", "label": "Rule name", "type": "text", "placeholder": "API rate limit"},
                        {"name": "rule_type", "label": "Rule type", "type": "text", "placeholder": "rate-limit"},
                        {"name": "action", "label": "Action", "type": "text", "placeholder": "challenge"},
                        {"name": "expression", "label": "Expression", "type": "textarea", "placeholder": "http.request.uri.path contains '/api/'"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "active"},
                        {"name": "priority", "label": "Priority", "type": "text", "placeholder": "10"},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Toggle rule state",
                    f"/control-plane/modules/{module_slug}/actions/toggle-rule",
                    [{"name": "rule_id", "label": "Rule", "type": "select", "options": rule_options}],
                )
            ],
        }

    if module_slug == "billing-wallet":
        plans = await list_rows(session, BillingPlan, 8)
        gateways = await list_rows(session, PaymentGateway, 8)
        wallets = await list_rows(session, WalletAccount, 8)
        wallet_options = [{"value": row.id, "label": row.wallet_name} for row in wallets]
        return {
            "summary_tiles": [
                {"label": "Plans", "value": len(plans)},
                {"label": "Gateways", "value": len(gateways)},
                {"label": "Wallets", "value": len(wallets)},
                {"label": "Live plans", "value": sum(1 for row in plans if row.status == "live")},
            ],
            "panels": [
                {"title": "Billing plans", "endpoint": "/api/billing-wallet/plans", "items": [_serialize_card(r, "name", ["vertical", "billing_provider", "cadence", "price_label", "status"], "summary") for r in plans]},
                {"title": "Payment gateways", "endpoint": "/api/billing-wallet/gateways", "items": [_serialize_card(r, "gateway_name", ["gateway_type", "settlement_asset", "status", "webhook_status"], "notes") for r in gateways]},
                {"title": "Wallet accounts", "endpoint": "/api/billing-wallet/wallets", "items": [_serialize_card(r, "wallet_name", ["wallet_type", "owner_scope", "network", "status"], extra_fields=["address_hint"]) for r in wallets]},
            ],
            "form": _form(
                "Create billing plan",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Plan name", "type": "text", "placeholder": "Enterprise Prime"},
                    {"name": "vertical", "label": "Vertical", "type": "text", "placeholder": "Cybersecurity"},
                    {"name": "billing_provider", "label": "Billing provider", "type": "text", "placeholder": "Stripe"},
                    {"name": "cadence", "label": "Cadence", "type": "text", "placeholder": "monthly"},
                    {"name": "price_label", "label": "Price label", "type": "text", "placeholder": "$2,500 / month"},
                    {"name": "currency", "label": "Currency", "type": "text", "placeholder": "USD"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "draft"},
                    {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Describe subscription scope, Web3 support, and billing behavior."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create payment gateway",
                    f"/control-plane/modules/{module_slug}/records/gateways/create",
                    [
                        {"name": "gateway_name", "label": "Gateway name", "type": "text", "placeholder": "Coinbase Commerce"},
                        {"name": "gateway_type", "label": "Gateway type", "type": "text", "placeholder": "web3"},
                        {"name": "settlement_asset", "label": "Settlement asset", "type": "text", "placeholder": "USDC"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "configured"},
                        {"name": "webhook_status", "label": "Webhook status", "type": "text", "placeholder": "healthy"},
                        {"name": "notes", "label": "Notes", "type": "textarea", "placeholder": "Dedicated payment gateway for crypto checkout and settlement."},
                    ],
                ),
                _form(
                    "Create wallet account",
                    f"/control-plane/modules/{module_slug}/records/wallets/create",
                    [
                        {"name": "wallet_name", "label": "Wallet name", "type": "text", "placeholder": "Executive Treasury"},
                        {"name": "wallet_type", "label": "Wallet type", "type": "text", "placeholder": "user-controlled"},
                        {"name": "owner_scope", "label": "Owner scope", "type": "text", "placeholder": "personal"},
                        {"name": "network", "label": "Network", "type": "text", "placeholder": "Base"},
                        {"name": "custody_model", "label": "Custody model", "type": "text", "placeholder": "self-custody"},
                        {"name": "address_hint", "label": "Address hint", "type": "text", "placeholder": "0xAB...1234"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "configured"},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Activate wallet",
                    f"/control-plane/modules/{module_slug}/actions/activate-wallet",
                    [{"name": "wallet_id", "label": "Wallet", "type": "select", "options": wallet_options}],
                )
            ],
        }

    if module_slug == "marketplace-console":
        offers = await list_rows(session, MarketplaceOffer, 8)
        articles = await list_rows(session, NewsArticle, 8)
        issues = await list_rows(session, NewsletterIssue, 8)
        article_options = [{"value": row.id, "label": row.title} for row in articles]
        newsletter_options = [{"value": row.id, "label": row.title} for row in issues]
        return {
            "summary_tiles": [
                {"label": "Offers", "value": len(offers)},
                {"label": "Articles", "value": len(articles)},
                {"label": "Newsletters", "value": len(issues)},
                {"label": "Published", "value": sum(1 for row in articles if row.status == "published")},
            ],
            "panels": [
                {"title": "Marketplace offers", "endpoint": "/api/marketplace-console/offers", "items": [_serialize_card(r, "name", ["vertical", "channel", "price_model", "status"], "summary") for r in offers]},
                {"title": "News feed", "endpoint": "/api/marketplace-console/articles", "items": [_serialize_card(r, "title", ["source_name", "status"], "description", extra_fields=["slug", "published_at"]) for r in articles]},
                {"title": "Newsletter issues", "endpoint": "/api/marketplace-console/newsletters", "items": [_serialize_card(r, "title", ["audience", "status", "send_window"], "hero_story") for r in issues]},
            ],
            "form": _form(
                "Create marketplace offer",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Offer name", "type": "text", "placeholder": "Cybersecurity premium package"},
                    {"name": "vertical", "label": "Vertical", "type": "text", "placeholder": "Cybersecurity"},
                    {"name": "channel", "label": "Channel", "type": "text", "placeholder": "Marketplace"},
                    {"name": "price_model", "label": "Price model", "type": "text", "placeholder": "Subscription"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "draft"},
                    {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Describe listing value, launch position, and news support."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create news article",
                    f"/control-plane/modules/{module_slug}/records/articles/create",
                    [
                        {"name": "title", "label": "Title", "type": "text", "placeholder": "Daily platform briefing"},
                        {"name": "slug", "label": "Slug", "type": "text", "placeholder": "daily-platform-briefing"},
                        {"name": "source_name", "label": "Source", "type": "text", "placeholder": "Telegram"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "queued"},
                        {"name": "image_url", "label": "Image URL", "type": "text", "placeholder": "/static/img/news-card.png"},
                        {"name": "description", "label": "Description", "type": "textarea", "placeholder": "Image-led summary for the news card."},
                        {"name": "body", "label": "Body", "type": "textarea", "placeholder": "Full news body for branded article detail."},
                    ],
                ),
                _form(
                    "Create newsletter issue",
                    f"/control-plane/modules/{module_slug}/records/newsletters/create",
                    [
                        {"name": "title", "label": "Issue title", "type": "text", "placeholder": "Platform Pulse #2"},
                        {"name": "audience", "label": "Audience", "type": "text", "placeholder": "Clients + subscribers"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "draft"},
                        {"name": "send_window", "label": "Send window", "type": "text", "placeholder": "08:00 ET"},
                        {"name": "hero_story", "label": "Hero story", "type": "textarea", "placeholder": "Top story summary for the issue."},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Publish article",
                    f"/control-plane/modules/{module_slug}/actions/publish-article",
                    [{"name": "article_id", "label": "Article", "type": "select", "options": article_options}],
                ),
                _workflow(
                    "Schedule newsletter",
                    f"/control-plane/modules/{module_slug}/actions/schedule-newsletter",
                    [
                        {"name": "newsletter_id", "label": "Newsletter", "type": "select", "options": newsletter_options},
                        {"name": "send_window", "label": "Send window", "type": "text", "placeholder": "09:00 ET"},
                    ],
                ),
            ],
        }

    if module_slug == "client-delivery":
        clients = await list_rows(session, ClientAccount, 8)
        teams = await list_rows(session, TeamWorkspace, 8)
        portfolios = await list_rows(session, ServicePortfolio, 8)
        client_options = [{"value": row.id, "label": row.name} for row in clients]
        team_options = [{"value": row.id, "label": row.name} for row in teams]
        return {
            "summary_tiles": [
                {"label": "Clients", "value": len(clients)},
                {"label": "Teams", "value": len(teams)},
                {"label": "Portfolios", "value": len(portfolios)},
                {"label": "Enterprise", "value": sum(1 for row in clients if row.service_tier.lower() == "enterprise")},
            ],
            "panels": [
                {"title": "Client accounts", "endpoint": "/api/client-delivery/clients", "items": [_serialize_card(r, "name", ["vertical", "service_tier", "status", "primary_contact"], "summary") for r in clients]},
                {"title": "Team workspaces", "endpoint": "/api/client-delivery/teams", "items": [_serialize_card(r, "name", ["vertical", "team_type", "member_capacity", "status"], "summary", extra_fields=["client_account_id"]) for r in teams]},
                {"title": "Service portfolios", "endpoint": "/api/client-delivery/portfolios", "items": [_serialize_card(r, "service_name", ["category", "status", "renewal_window"], "notes", extra_fields=["client_account_id", "team_workspace_id"]) for r in portfolios]},
            ],
            "form": _form(
                "Create client account",
                f"/control-plane/modules/{module_slug}/records/create",
                [
                    {"name": "name", "label": "Client name", "type": "text", "placeholder": "Flagship Holdings"},
                    {"name": "vertical", "label": "Vertical", "type": "text", "placeholder": "Real Estate"},
                    {"name": "primary_contact", "label": "Primary contact", "type": "text", "placeholder": "client@example.com"},
                    {"name": "service_tier", "label": "Service tier", "type": "text", "placeholder": "Enterprise"},
                    {"name": "status", "label": "Status", "type": "text", "placeholder": "active"},
                    {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Describe the portal, monitoring, and delivery scope."},
                ],
            ),
            "secondary_forms": [
                _form(
                    "Create team workspace",
                    f"/control-plane/modules/{module_slug}/records/teams/create",
                    [
                        {"name": "name", "label": "Team name", "type": "text", "placeholder": "Real Estate Portfolio Team"},
                        {"name": "client_account_id", "label": "Client", "type": "select", "options": client_options, "optional": True},
                        {"name": "vertical", "label": "Vertical", "type": "text", "placeholder": "Real Estate"},
                        {"name": "team_type", "label": "Team type", "type": "text", "placeholder": "delivery"},
                        {"name": "member_capacity", "label": "Member capacity", "type": "text", "placeholder": "50"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "active"},
                        {"name": "summary", "label": "Summary", "type": "textarea", "placeholder": "Global team workspace for client delivery and operations."},
                    ],
                ),
                _form(
                    "Create service portfolio",
                    f"/control-plane/modules/{module_slug}/records/portfolios/create",
                    [
                        {"name": "client_account_id", "label": "Client", "type": "select", "options": client_options},
                        {"name": "team_workspace_id", "label": "Team", "type": "select", "options": team_options, "optional": True},
                        {"name": "service_name", "label": "Service name", "type": "text", "placeholder": "Managed Security Operations"},
                        {"name": "category", "label": "Category", "type": "text", "placeholder": "Managed Service"},
                        {"name": "status", "label": "Status", "type": "text", "placeholder": "active"},
                        {"name": "renewal_window", "label": "Renewal window", "type": "text", "placeholder": "Q4 review"},
                        {"name": "notes", "label": "Notes", "type": "textarea", "placeholder": "Assign service scope and delivery notes."},
                    ],
                ),
            ],
            "workflow_actions": [
                _workflow(
                    "Assign team to client",
                    f"/control-plane/modules/{module_slug}/actions/assign-team",
                    [
                        {"name": "team_id", "label": "Team", "type": "select", "options": team_options},
                        {"name": "client_account_id", "label": "Client", "type": "select", "options": client_options, "optional": True},
                    ],
                ),
                _workflow(
                    "Activate portfolio",
                    f"/control-plane/modules/{module_slug}/actions/activate-portfolio",
                    [
                        {"name": "portfolio_id", "label": "Portfolio", "type": "select", "options": [{"value": row.id, "label": row.service_name} for row in portfolios]},
                        {"name": "team_workspace_id", "label": "Team", "type": "select", "options": team_options, "optional": True},
                    ],
                ),
            ],
        }

    return {"summary_tiles": [], "panels": [], "form": None, "secondary_forms": [], "workflow_actions": []}


PRIMARY_RECORD_CREATORS = {
    "website-studio": (create_website_project, WebsiteProjectCreate),
    "infrastructure-console": (create_deployment_project, DeploymentProjectCreate),
    "cloudflare-console": (create_cloudflare_zone, CloudflareZoneCreate),
    "billing-wallet": (create_billing_plan, BillingPlanCreate),
    "marketplace-console": (create_marketplace_offer, MarketplaceOfferCreate),
    "client-delivery": (create_client_account, ClientAccountCreate),
}

SECONDARY_RECORD_CREATORS = {
    ("website-studio", "pages"): (create_website_page, WebsitePageCreate),
    ("website-studio", "sections"): (create_page_section, PageSectionCreate),
    ("website-studio", "assets"): (create_brand_asset, BrandAssetCreate),
    ("website-studio", "releases"): (create_publish_release, PublishReleaseCreate),
    ("infrastructure-console", "environments"): (create_environment_profile, EnvironmentProfileCreate),
    ("infrastructure-console", "domains"): (create_domain_binding, DomainBindingCreate),
    ("infrastructure-console", "release-events"): (create_release_audit_event, ReleaseAuditEventCreate),
    ("cloudflare-console", "rules"): (create_cloudflare_rule, CloudflareRuleCreate),
    ("billing-wallet", "gateways"): (create_payment_gateway, PaymentGatewayCreate),
    ("billing-wallet", "wallets"): (create_wallet_account, WalletAccountCreate),
    ("marketplace-console", "articles"): (create_news_article, NewsArticleCreate),
    ("marketplace-console", "newsletters"): (create_newsletter_issue, NewsletterIssueCreate),
    ("client-delivery", "teams"): (create_team_workspace, TeamWorkspaceCreate),
    ("client-delivery", "portfolios"): (create_service_portfolio, ServicePortfolioCreate),
}

UPDATE_SCHEMAS: dict[type, Type[Any]] = {
    WebsiteProject: WebsiteProjectUpdate,
    WebsitePage: WebsitePageUpdate,
    PageSection: PageSectionUpdate,
    BrandAsset: BrandAssetUpdate,
    PublishRelease: PublishReleaseUpdate,
    DeploymentProject: DeploymentProjectUpdate,
    EnvironmentProfile: EnvironmentProfileUpdate,
    DomainBinding: DomainBindingUpdate,
    CloudflareZone: CloudflareZoneUpdate,
    CloudflareRule: CloudflareRuleUpdate,
    BillingPlan: BillingPlanUpdate,
    PaymentGateway: PaymentGatewayUpdate,
    WalletAccount: WalletAccountUpdate,
    MarketplaceOffer: MarketplaceOfferUpdate,
    NewsArticle: NewsArticleUpdate,
    NewsletterIssue: NewsletterIssueUpdate,
    ClientAccount: ClientAccountUpdate,
    TeamWorkspace: TeamWorkspaceUpdate,
    ServicePortfolio: ServicePortfolioUpdate,
}

UPDATE_HANDLERS = {
    WebsiteProject: update_website_project,
    WebsitePage: update_website_page,
    PageSection: update_page_section,
    BrandAsset: update_brand_asset,
    PublishRelease: update_publish_release,
    DeploymentProject: update_deployment_project,
    EnvironmentProfile: update_environment_profile,
    DomainBinding: update_domain_binding,
    CloudflareZone: update_cloudflare_zone,
    CloudflareRule: update_cloudflare_rule,
    BillingPlan: update_billing_plan,
    PaymentGateway: update_payment_gateway,
    WalletAccount: update_wallet_account,
    MarketplaceOffer: update_marketplace_offer,
    NewsArticle: update_news_article,
    NewsletterIssue: update_newsletter_issue,
    ClientAccount: update_client_account,
    TeamWorkspace: update_team_workspace,
    ServicePortfolio: update_service_portfolio,
}


async def create_primary_record(session: AsyncSession, module_slug: str, payload: dict[str, Any]) -> Any:
    if module_slug not in PRIMARY_RECORD_CREATORS:
        raise ValueError(f"Unsupported module slug for primary record creation: {module_slug}")
    creator, schema = PRIMARY_RECORD_CREATORS[module_slug]
    return await creator(session, schema(**payload))


async def create_secondary_record(session: AsyncSession, module_slug: str, record_key: str, payload: dict[str, Any]) -> Any:
    key = (module_slug, record_key)
    if key not in SECONDARY_RECORD_CREATORS:
        raise ValueError(f"Unsupported secondary record: {module_slug}/{record_key}")
    creator, schema = SECONDARY_RECORD_CREATORS[key]
    return await creator(session, schema(**payload))


async def update_model_record(session: AsyncSession, model: type, row: Any, payload: dict[str, Any]) -> Any:
    schema = UPDATE_SCHEMAS[model]
    handler = UPDATE_HANDLERS[model]
    return await handler(session, row, schema(**payload))


async def seed_module_entities(session: AsyncSession) -> None:
    existing = await session.execute(select(WebsiteProject.id).limit(1))
    if existing.first():
        return

    project = WebsiteProject(
        name="Corporate launch site",
        slug="corporate-launch-site",
        vertical="Cybersecurity",
        status="review",
        primary_domain="launch.gem.example",
        owner_name="Platform Admin",
        summary="Flagship public website for cybersecurity, real estate, marketing, Bentley, and developer service pages.",
    )
    session.add(project)
    await session.commit()
    await session.refresh(project)

    page = WebsitePage(
        project_id=project.id,
        title="Cybersecurity Services",
        slug="cybersecurity-services",
        page_type="service",
        status="review",
        hero_title="Enterprise cybersecurity operations",
        seo_title="Cybersecurity Services | GEM",
        seo_description="Managed security, monitoring, threat analysis, and automation.",
        sort_order=1,
    )
    session.add(page)
    await session.commit()
    await session.refresh(page)

    session.add(PageSection(page_id=page.id, section_key="hero", title="Hero", body="High-trust landing block with CTA and vertical messaging.", component_type="hero", sort_order=1))
    session.add(BrandAsset(project_id=project.id, asset_type="logo", name="Primary brand lockup", file_url="/static/img/logo.svg", usage_context="Global header", is_primary=True))
    session.add(PublishRelease(project_id=project.id, version_label="v0.9", environment="preview", status="pending", notes="Awaiting final publish approval."))

    deployment = DeploymentProject(
        name="Unified production stack",
        provider="Cloudflare",
        target_stack="FastAPI + Edge",
        status="active",
        primary_domain="app.gem.example",
        repo_url="https://github.com/support371/GemAiAgent",
        summary="Server-integrated deployment project for preview, staging, and production.",
    )
    session.add(deployment)
    await session.commit()
    await session.refresh(deployment)

    session.add(EnvironmentProfile(deployment_project_id=deployment.id, name="production", stage="production", app_url="https://app.gem.example", deployment_status="healthy", health_status="green", region="global"))
    session.add(DomainBinding(deployment_project_id=deployment.id, hostname="app.gem.example", dns_provider="Cloudflare", ssl_mode="strict", status="active", cdn_enabled=True))
    session.add(ReleaseAuditEvent(deployment_project_id=deployment.id, event_type="promotion", actor_name="Ops Lead", target_environment="production", detail="Preview build promoted after release checks passed."))

    zone = CloudflareZone(name="Primary edge zone", zone_name="gem.example", status="active", ssl_mode="strict", waf_mode="managed", cache_strategy="standard", notes="Protect public sites, APIs, and portal surfaces.")
    session.add(zone)
    await session.commit()
    await session.refresh(zone)
    session.add(CloudflareRule(zone_id=zone.id, rule_name="API rate limit", rule_type="rate-limit", action="challenge", expression="http.request.uri.path contains '/api/'", status="active", priority=10))

    session.add(BillingPlan(name="Enterprise Prime", vertical="Cybersecurity", billing_provider="Stripe", cadence="monthly", price_label="$2,500 / month", currency="USD", status="live", summary="Managed security, reporting, monitoring, and client portal access."))
    session.add(PaymentGateway(gateway_name="Coinbase Commerce", gateway_type="web3", settlement_asset="USDC", status="configured", webhook_status="healthy", notes="Crypto checkout for platform offers and treasury intake."))
    session.add(WalletAccount(wallet_name="Executive Treasury", wallet_type="user-controlled", owner_scope="personal", network="Base", custody_model="self-custody", address_hint="0xA1...9F3C", status="configured"))

    session.add(MarketplaceOffer(name="Cybersecurity Premium", vertical="Cybersecurity", channel="Marketplace", price_model="Subscription", status="review", summary="Full-stack managed security package with dashboards, monitoring, and automation."))
    session.add(NewsArticle(title="Daily threat operations briefing", slug="daily-threat-operations-briefing", source_name="Telegram", status="published", image_url="/static/img/news-card.png", description="Fresh telemetry-backed summary for the daily platform feed.", body="News body placeholder for the branded card layout.", published_at=datetime.utcnow()))
    session.add(NewsletterIssue(title="Platform Pulse #1", audience="Clients + subscribers", status="scheduled", send_window="08:00 ET", hero_story="Threat dashboard rollout + marketplace expansion"))

    client = ClientAccount(name="Flagship Realty Group", vertical="Real Estate", primary_contact="operations@flagship.example", service_tier="Enterprise", status="active", summary="Client portal with portfolio visibility, onboarding, and service operations.")
    session.add(client)
    await session.commit()
    await session.refresh(client)
    team = TeamWorkspace(name="Cybersecurity Operations Team", client_account_id=client.id, vertical="Cybersecurity", team_type="operations", member_capacity=50, status="active", summary="Central operations team for monitoring, threat review, and incident coordination.")
    session.add(team)
    await session.commit()
    await session.refresh(team)
    session.add(ServicePortfolio(client_account_id=client.id, team_workspace_id=team.id, service_name="Managed Security Operations", category="Managed Service", status="active", renewal_window="Q4 review", notes="Includes dashboards, alerts, and monthly executive reporting."))

    await session.commit()
