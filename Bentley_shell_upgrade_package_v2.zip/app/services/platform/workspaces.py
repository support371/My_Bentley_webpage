from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.models.control_plane import ControlPlaneWorkspace
from app.schemas.control_plane import WorkspaceCreate, WorkspaceUpdate
from app.services.platform.catalog import CONTROL_MODULE_ORDER, get_control_module


_ALLOWED_STATUSES = {"planned", "active", "live", "blocked", "archived"}
_ALLOWED_ENVIRONMENTS = {"local", "preview", "staging", "production"}
_ALLOWED_PRIORITIES = {"low", "medium", "high", "critical"}


async def list_workspaces(
    session: AsyncSession,
    module_slug: Optional[str] = None,
    limit: int = 100,
) -> list[ControlPlaneWorkspace]:
    statement = select(ControlPlaneWorkspace).order_by(ControlPlaneWorkspace.updated_at.desc())
    if module_slug:
        statement = statement.where(ControlPlaneWorkspace.module_slug == module_slug)
    result = await session.execute(statement.limit(limit))
    return list(result.scalars().all())


async def get_workspace(session: AsyncSession, workspace_id: str) -> Optional[ControlPlaneWorkspace]:
    return await session.get(ControlPlaneWorkspace, workspace_id)


async def create_workspace(session: AsyncSession, payload: WorkspaceCreate) -> ControlPlaneWorkspace:
    validate_module_slug(payload.module_slug)
    workspace = ControlPlaneWorkspace(
        module_slug=payload.module_slug,
        name=payload.name.strip(),
        vertical=(payload.vertical or "Cybersecurity").strip(),
        status=normalize_status(payload.status),
        environment=normalize_environment(payload.environment),
        priority=normalize_priority(payload.priority),
        owner_name=(payload.owner_name or None),
        summary=(payload.summary or None),
        metadata_json=(payload.metadata_json or None),
    )
    session.add(workspace)
    await session.commit()
    await session.refresh(workspace)
    return workspace


async def update_workspace(
    session: AsyncSession,
    workspace: ControlPlaneWorkspace,
    payload: WorkspaceUpdate,
) -> ControlPlaneWorkspace:
    updates = payload.model_dump(exclude_unset=True) if hasattr(payload, "model_dump") else payload.dict(exclude_unset=True)
    for field, value in updates.items():
        if field == "status" and value is not None:
            value = normalize_status(value)
        elif field == "environment" and value is not None:
            value = normalize_environment(value)
        elif field == "priority" and value is not None:
            value = normalize_priority(value)
        setattr(workspace, field, value)
    workspace.updated_at = datetime.utcnow()
    session.add(workspace)
    await session.commit()
    await session.refresh(workspace)
    return workspace


async def delete_workspace(session: AsyncSession, workspace: ControlPlaneWorkspace) -> None:
    await session.delete(workspace)
    await session.commit()


def summarize_workspace_rows(rows: list[ControlPlaneWorkspace]) -> dict[str, Any]:
    status_counts = defaultdict(int)
    vertical_counts = defaultdict(int)
    for row in rows:
        status_counts[row.status] += 1
        vertical_counts[row.vertical] += 1
    return {
        "total": len(rows),
        "status_counts": dict(status_counts),
        "vertical_counts": dict(vertical_counts),
        "production_ready": sum(1 for row in rows if row.environment == "production"),
    }


async def summarize_workspaces_by_module(session: AsyncSession) -> dict[str, dict[str, int]]:
    rows = await list_workspaces(session, limit=500)
    summary: dict[str, dict[str, int]] = {
        slug: {"total": 0, "live": 0, "active": 0, "production": 0}
        for slug in CONTROL_MODULE_ORDER
    }
    for row in rows:
        bucket = summary.setdefault(row.module_slug, {"total": 0, "live": 0, "active": 0, "production": 0})
        bucket["total"] += 1
        if row.status == "live":
            bucket["live"] += 1
        if row.status in {"active", "live"}:
            bucket["active"] += 1
        if row.environment == "production":
            bucket["production"] += 1
    return summary


async def seed_control_plane_workspaces(session: AsyncSession) -> None:
    rows = await list_workspaces(session, limit=2)
    if rows:
        return

    starter_rows = [
        WorkspaceCreate(
            module_slug="website-studio",
            name="Corporate launch site",
            vertical="Cybersecurity",
            status="active",
            environment="preview",
            priority="critical",
            owner_name="Platform Admin",
            summary="Build the core branded website stack and finalize flagship service pages.",
        ),
        WorkspaceCreate(
            module_slug="infrastructure-console",
            name="Production environment registry",
            vertical="Platform",
            status="planned",
            environment="staging",
            priority="high",
            owner_name="Ops Lead",
            summary="Track environments, domain bindings, and release controls from one console.",
        ),
        WorkspaceCreate(
            module_slug="cloudflare-console",
            name="Edge security policy rollout",
            vertical="Cybersecurity",
            status="planned",
            environment="production",
            priority="critical",
            owner_name="Security Lead",
            summary="Apply Cloudflare WAF rules, SSL posture, rate limits, and DNS governance.",
        ),
        WorkspaceCreate(
            module_slug="billing-wallet",
            name="SaaS billing and treasury",
            vertical="Finance",
            status="planned",
            environment="preview",
            priority="high",
            owner_name="Finance Ops",
            summary="Launch Stripe subscriptions and Web3 wallet controls under one billing surface.",
        ),
        WorkspaceCreate(
            module_slug="marketplace-console",
            name="Marketplace and news launch",
            vertical="Marketing",
            status="planned",
            environment="preview",
            priority="medium",
            owner_name="Growth Team",
            summary="Move platform offers into market, syndicate news, and manage newsletter automation.",
        ),
        WorkspaceCreate(
            module_slug="client-delivery",
            name="Client and team portal rollout",
            vertical="Real Estate",
            status="planned",
            environment="staging",
            priority="high",
            owner_name="Client Success",
            summary="Stand up client delivery portals, team workspaces, and admin controls.",
        ),
    ]

    for payload in starter_rows:
        await create_workspace(session, payload)


def validate_module_slug(slug: str) -> None:
    try:
        get_control_module(slug)
    except KeyError as exc:
        raise ValueError(f"Unsupported module slug: {slug}") from exc


def normalize_status(value: str) -> str:
    value = (value or "planned").strip().lower()
    return value if value in _ALLOWED_STATUSES else "planned"


def normalize_environment(value: str) -> str:
    value = (value or "preview").strip().lower()
    return value if value in _ALLOWED_ENVIRONMENTS else "preview"


def normalize_priority(value: str) -> str:
    value = (value or "high").strip().lower()
    return value if value in _ALLOWED_PRIORITIES else "high"


def build_module_detail(module_slug: str, rows: list[ControlPlaneWorkspace]) -> Dict[str, Any]:
    module = get_control_module(module_slug)
    metrics = summarize_workspace_rows(rows)
    module["workspace_metrics"] = metrics
    module.setdefault("api_endpoints", [])
    extra_endpoints = [
        f"GET /api/control-plane/modules/{module_slug}/workspaces",
        "GET /api/control-plane/workspaces",
        "POST /api/control-plane/workspaces",
    ]
    for endpoint in extra_endpoints:
        if endpoint not in module["api_endpoints"]:
            module["api_endpoints"].append(endpoint)
    module["workspaces"] = [
        {
            "id": row.id,
            "name": row.name,
            "vertical": row.vertical,
            "status": row.status,
            "environment": row.environment,
            "priority": row.priority,
            "owner_name": row.owner_name,
            "summary": row.summary,
            "updated_at": row.updated_at.isoformat() + "Z",
        }
        for row in rows
    ]
    return module
