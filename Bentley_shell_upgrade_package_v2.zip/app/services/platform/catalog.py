from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List

CONTROL_MODULE_ORDER = [
    "website-studio",
    "infrastructure-console",
    "cloudflare-console",
    "billing-wallet",
    "marketplace-console",
    "client-delivery",
]

_MODULES: List[Dict[str, Any]] = [
    {
        "slug": "website-studio",
        "name": "Website Studio",
        "stage": "Build",
        "status": "active",
        "headline": "Finalize branded public websites, service detail pages, and the publish workflow.",
        "summary": "Turns the platform into a multi-vertical web presence for Cybersecurity, Real Estate, Bentley, Developer Tools, Marketing, Community, and News.",
        "objectives": [
            "Launch single-page and multi-page websites per service line",
            "Manage draft, review, approval, publish, and archive states",
            "Centralize branding, CTA blocks, trust signals, and page-level SEO",
        ],
        "frontend_surfaces": [
            "Website builder workspace",
            "Live preview and publish confirmation",
            "Service page templates for Cybersecurity, Real Estate, Bentley, Developer Tools, Marketing, Legal, Logistics, Community, and News",
            "Asset gallery for logos, hero media, screenshots, and feature cards",
        ],
        "backend_capabilities": [
            "Page configuration and section schema service",
            "Draft and published state tracking",
            "Version history and release notes",
            "Domain mapping and environment metadata",
        ],
        "data_models": [
            "WebsiteProject",
            "WebsitePage",
            "PageSection",
            "BrandAsset",
            "PublishRelease",
        ],
        "api_endpoints": [
            "GET /api/website-studio",
            "GET /api/control-plane/modules/website-studio",
        ],
        "control_panels": [
            "Website finalization page",
            "Brand governance panel",
            "Publish approvals queue",
        ],
        "automation": [
            "Scheduled publish windows",
            "Automated content expiry and refresh rules",
            "Preview link generation",
        ],
        "requirements": [
            "Brand/logo library",
            "Service page copy",
            "Environment-aware publish rules",
        ],
        "resources": [
            "Hero template library",
            "SEO metadata presets",
            "CTA and contact form components",
        ],
        "kpis": [
            {"label": "Projects", "value": "9"},
            {"label": "Page states", "value": "Draft / Review / Live"},
            {"label": "Critical milestone", "value": "Public site finalized"},
        ],
    },
    {
        "slug": "infrastructure-console",
        "name": "Infrastructure Console",
        "stage": "Secure the build lane",
        "status": "active",
        "headline": "Integrate the server, environments, deployments, domains, and runtime controls.",
        "summary": "Operates the server-integrated website stack and gives admins a single console for preview, production, rollout, rollback, and environment health.",
        "objectives": [
            "Surface environment and release health from one place",
            "Track domains, secrets references, queues, workers, and background jobs",
            "Connect website finalization directly to deployment readiness",
        ],
        "frontend_surfaces": [
            "Environment matrix for local, preview, staging, and production",
            "Deployment timeline and release gate view",
            "Server health, job queue, and error drilldown panels",
        ],
        "backend_capabilities": [
            "Deployment registry and runtime metadata service",
            "Audit events for releases and rollback actions",
            "Server configuration, secret reference, and domain binding models",
        ],
        "data_models": [
            "DeploymentProject",
            "EnvironmentProfile",
            "DomainBinding",
            "SecretReference",
            "ReleaseAuditEvent",
        ],
        "api_endpoints": [
            "GET /api/infrastructure-console",
            "GET /api/control-plane/modules/infrastructure-console",
        ],
        "control_panels": [
            "Production console",
            "Rollback control panel",
            "Domain and environment manager",
        ],
        "automation": [
            "Deployment checklist validation",
            "Release gate notifications",
            "Health snapshot refresh",
        ],
        "requirements": [
            "Environment inventory",
            "Domain ownership and DNS readiness",
            "Operational rollback policy",
        ],
        "resources": [
            "Release checklist",
            "Runbook references",
            "Environment topology map",
        ],
        "kpis": [
            {"label": "Environments", "value": "4"},
            {"label": "Release gate", "value": "Server-integrated"},
            {"label": "Operational mode", "value": "Preview → Production"},
        ],
    },
    {
        "slug": "cloudflare-console",
        "name": "Cloudflare Console",
        "stage": "Harden edge security",
        "status": "next",
        "headline": "Centralize edge rules, DNS, SSL/TLS, WAF, caching, bot controls, and incident response.",
        "summary": "Makes Cloudflare a first-class governance surface instead of a buried settings page.",
        "objectives": [
            "Protect the platform before major public traffic and automation scale",
            "Expose rule management, challenge policy, rate limits, and DNS readiness",
            "Tie security posture to production releases and incident logging",
        ],
        "frontend_surfaces": [
            "Security policy dashboard",
            "Threat activity and challenge review",
            "DNS, SSL/TLS, cache, and rate-limit tabs",
        ],
        "backend_capabilities": [
            "Cloudflare integration layer",
            "Policy sync and drift detection jobs",
            "Incident log and rule change history",
        ],
        "data_models": [
            "SecurityRuleProfile",
            "EdgePolicyChange",
            "ThreatSignal",
            "ZoneConfiguration",
            "IncidentResponseRun",
        ],
        "api_endpoints": [
            "GET /api/cloudflare-console",
            "GET /api/control-plane/modules/cloudflare-console",
        ],
        "control_panels": [
            "WAF and rules console",
            "Threat operations board",
            "DNS and SSL readiness view",
        ],
        "automation": [
            "Rule sync checks",
            "Threat posture snapshots",
            "Incident escalation hooks",
        ],
        "requirements": [
            "Zone inventory",
            "Baseline security policy",
            "Rate-limit thresholds per surface",
        ],
        "resources": [
            "Security runbooks",
            "Rule templates",
            "Threat severity mapping",
        ],
        "kpis": [
            {"label": "Security layers", "value": "WAF / DNS / TLS / Rate limits"},
            {"label": "Priority", "value": "Protect production edge"},
            {"label": "Ops mode", "value": "Policy-driven"},
        ],
    },
    {
        "slug": "billing-wallet",
        "name": "Billing + Web3 Wallet",
        "stage": "Monetize",
        "status": "next",
        "headline": "Add fiat subscriptions, invoicing, crypto checkout, and private wallet control surfaces.",
        "summary": "Creates a dedicated payment gateway with Web2 and Web3 billing lanes for clients, admins, and treasury operations.",
        "objectives": [
            "Support SaaS subscriptions, invoices, and payment status monitoring",
            "Expose dedicated Web3 checkout and wallet control panel views",
            "Separate personal wallet privacy from business treasury automation",
        ],
        "frontend_surfaces": [
            "Billing dashboard and plan catalog",
            "Invoice history and subscription manager",
            "Private wallet account control panel and treasury overview",
        ],
        "backend_capabilities": [
            "Plan, invoice, and payment webhook services",
            "Wallet metadata, permissions, and audit logging",
            "Settlement tracking for fiat and Web3 channels",
        ],
        "data_models": [
            "SubscriptionPlan",
            "ClientInvoice",
            "PaymentIntent",
            "WalletAccount",
            "TreasuryLedger",
        ],
        "api_endpoints": [
            "GET /api/billing-wallet",
            "GET /api/control-plane/modules/billing-wallet",
        ],
        "control_panels": [
            "Dedicated payment gateway page",
            "Personal wallet privacy panel",
            "Business treasury maintenance view",
        ],
        "automation": [
            "Invoice reminders",
            "Payment status webhooks",
            "Wallet activity logging",
        ],
        "requirements": [
            "Plan matrix and pricing policy",
            "Treasury ownership rules",
            "Crypto payment acceptance policy",
        ],
        "resources": [
            "Plan templates",
            "Billing lifecycle map",
            "Wallet risk controls",
        ],
        "kpis": [
            {"label": "Payment lanes", "value": "Fiat + Web3"},
            {"label": "Wallet modes", "value": "Personal + Treasury"},
            {"label": "Business goal", "value": "Monetize services"},
        ],
    },
    {
        "slug": "marketplace-console",
        "name": "Marketplace + News Console",
        "stage": "Go to market",
        "status": "next",
        "headline": "Move finalized production assets into offers, marketplace packaging, news, newsletters, and social distribution.",
        "summary": "Combines market-phase launch management with the branded news and newsletter operation requested for the platform.",
        "objectives": [
            "Launch offers and service bundles into the market phase",
            "Operate the platform news feed, newsletter, and card-based media distribution",
            "Coordinate social account automation and publication cadences",
        ],
        "frontend_surfaces": [
            "Marketplace / GTM console",
            "News hub with image-led cards",
            "Newsletter builder and social distribution planner",
        ],
        "backend_capabilities": [
            "Offer catalog and launch workflow service",
            "News ingestion and editorial queue",
            "Telegram and channel automation connectors",
        ],
        "data_models": [
            "OfferPackage",
            "LaunchCampaign",
            "NewsArticle",
            "NewsletterEdition",
            "SocialDistributionJob",
        ],
        "api_endpoints": [
            "GET /api/marketplace-console",
            "GET /api/control-plane/modules/marketplace-console",
        ],
        "control_panels": [
            "Market phase console",
            "News and newsletter manager",
            "Social content automation board",
        ],
        "automation": [
            "Telegram ingest",
            "Fresh-content distribution queue",
            "Newsletter assembly and send windows",
        ],
        "requirements": [
            "Editorial standards",
            "Launch package definitions",
            "Content approval policy",
        ],
        "resources": [
            "News card template library",
            "Marketplace listing pack",
            "Distribution channel matrix",
        ],
        "kpis": [
            {"label": "Go-live surfaces", "value": "Marketplace + News + Social"},
            {"label": "Automation mode", "value": "Editorial + Channel sync"},
            {"label": "Launch focus", "value": "Market execution"},
        ],
    },
    {
        "slug": "client-delivery",
        "name": "Client Delivery",
        "stage": "Operate",
        "status": "later",
        "headline": "Expose client portals, real-estate and cybersecurity team dashboards, and super-admin governance.",
        "summary": "Completes the SaaS operating layer once the platform is built, secured, and monetized.",
        "objectives": [
            "Deliver client-facing portals and service visibility",
            "Support 50 real estate teams and 50 cybersecurity teams under one governance model",
            "Separate admin, super-admin, team, and client views cleanly",
        ],
        "frontend_surfaces": [
            "Client portal and service overview",
            "Real Estate team dashboard",
            "Cybersecurity team dashboard",
            "Super-admin control plane",
        ],
        "backend_capabilities": [
            "Client account and entitlement services",
            "Team workspace orchestration",
            "Case, monitoring, reporting, and document access",
        ],
        "data_models": [
            "ClientAccount",
            "TeamWorkspace",
            "ServicePortfolio",
            "ThreatCase",
            "AccessRoleGrant",
        ],
        "api_endpoints": [
            "GET /api/client-delivery",
            "GET /api/control-plane/modules/client-delivery",
        ],
        "control_panels": [
            "Client portal admin",
            "Team dashboard manager",
            "Super-admin governance center",
        ],
        "automation": [
            "Role provisioning",
            "Portfolio status updates",
            "Team activity reporting",
        ],
        "requirements": [
            "RBAC matrix",
            "Client service packages",
            "Team dashboard taxonomy",
        ],
        "resources": [
            "Portal templates",
            "Governance policies",
            "Reporting dashboards",
        ],
        "kpis": [
            {"label": "Teams", "value": "50 Real Estate + 50 Cybersecurity"},
            {"label": "Views", "value": "Client / Team / Admin / Super-admin"},
            {"label": "Outcome", "value": "Live service delivery"},
        ],
    },
]

CONTROL_PLANE_OVERVIEW: Dict[str, Any] = {
    "flow_name": "Build → Secure → Monetize → Operate",
    "core_divisions": [
        {
            "name": "Cybersecurity",
            "summary": "Monitoring, threat analysis, alerting, incident review, private security operations, and client assurance.",
        },
        {
            "name": "Real Estate",
            "summary": "Property services, investment-facing portals, branded websites, document flows, and client delivery.",
        },
    ],
    "shared_capabilities": [
        "Bentley operations",
        "Developer tools and deployment services",
        "Marketing automation",
        "News and newsletters",
        "Legal and logistics workflows",
        "Community and social account management",
    ],
    "modules": _MODULES,
}


def get_control_plane() -> Dict[str, Any]:
    return deepcopy(CONTROL_PLANE_OVERVIEW)



def list_control_modules() -> List[Dict[str, Any]]:
    return deepcopy(_MODULES)



def get_control_module(slug: str) -> Dict[str, Any]:
    for idx, module in enumerate(_MODULES):
        if module["slug"] == slug:
            current = deepcopy(module)
            prev_slug = _MODULES[idx - 1]["slug"] if idx > 0 else None
            next_slug = _MODULES[idx + 1]["slug"] if idx < len(_MODULES) - 1 else None
            current["sequence"] = idx + 1
            current["previous_slug"] = prev_slug
            current["next_slug"] = next_slug
            current["previous_name"] = next((m["name"] for m in _MODULES if m["slug"] == prev_slug), None)
            current["next_name"] = next((m["name"] for m in _MODULES if m["slug"] == next_slug), None)
            return current
    raise KeyError(slug)
