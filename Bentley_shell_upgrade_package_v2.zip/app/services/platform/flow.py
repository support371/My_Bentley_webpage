from __future__ import annotations

from typing import Any, Dict, List


def get_universal_launch_flow() -> Dict[str, Any]:
    """Return the recommended single operating flow for the expanded platform."""

    phases: List[Dict[str, Any]] = [
        {
            "id": "phase-1",
            "name": "Website Studio",
            "route": "/website-studio",
            "status": "now",
            "headline": "Finalize the public-facing service websites first.",
            "objective": "Create the branded front-end pages for Cybersecurity, Real Estate, Bentley, Developer Tools, Marketing, News, Community, and Contact.",
            "frontend": [
                "Landing pages and service detail pages",
                "Page builder / preview / publish workflow",
                "Brand assets, logo, hero blocks, trust signals",
            ],
            "backend": [
                "Page configuration model",
                "Draft / published states",
                "Domain and environment metadata",
            ],
            "deliverables": [
                "Website page",
                "Website finalization page",
                "Service showcase pages",
            ],
        },
        {
            "id": "phase-2",
            "name": "Infrastructure Console",
            "route": "/infrastructure-console",
            "status": "now",
            "headline": "Wire the server, environments, and deployment controls.",
            "objective": "Give admins one place to manage preview, production, domains, secrets, jobs, queues, and deployment status.",
            "frontend": [
                "Environment overview",
                "Runtime health and deployment logs",
                "Release / rollback controls",
            ],
            "backend": [
                "Deployment project registry",
                "Environment configuration service",
                "Server health, job queue, and audit events",
            ],
            "deliverables": [
                "Server-integrated website page",
                "Production console",
                "Deployment controls",
            ],
        },
        {
            "id": "phase-3",
            "name": "Cloudflare Security",
            "route": "/cloudflare-console",
            "status": "next",
            "headline": "Protect the edge before scaling traffic.",
            "objective": "Centralize DNS, WAF, rate limits, caching, SSL/TLS, bot controls, and API protection.",
            "frontend": [
                "Security rules dashboard",
                "Threat and challenge activity",
                "Policy toggles and change history",
            ],
            "backend": [
                "Cloudflare connector layer",
                "Security policy sync jobs",
                "Rule evaluation and incident logging",
            ],
            "deliverables": [
                "Cloudflare console",
                "Rule management",
                "Production-proof security layer",
            ],
        },
        {
            "id": "phase-4",
            "name": "Billing + Web3 Wallet",
            "route": "/billing-wallet",
            "status": "next",
            "headline": "Monetize with both fiat and Web3-ready payment rails.",
            "objective": "Support subscriptions, invoices, crypto checkout, and controlled wallet connections inside the admin control panel.",
            "frontend": [
                "Billing dashboard",
                "Subscription plans and invoices",
                "Wallet connection and treasury views",
            ],
            "backend": [
                "Plan and invoice models",
                "Payment webhook processing",
                "Wallet metadata, permissions, and audit trails",
            ],
            "deliverables": [
                "Dedicated payment gateway page",
                "Web3 wallet control panel section",
                "Client billing workflows",
            ],
        },
        {
            "id": "phase-5",
            "name": "Marketplace + News",
            "route": "/marketplace-console",
            "status": "next",
            "headline": "Move from production to market execution.",
            "objective": "Package offers, launch services, run campaigns, and syndicate platform news, newsletters, and social content.",
            "frontend": [
                "Marketplace / GTM console",
                "News cards and newsletter builder",
                "Content approval and schedule views",
            ],
            "backend": [
                "Offer catalog and launch workflow",
                "News ingestion and editorial workflow",
                "Automation scheduler and channel connectors",
            ],
            "deliverables": [
                "Market phase page",
                "News platform",
                "Newsletter operations",
            ],
        },
        {
            "id": "phase-6",
            "name": "Client Delivery",
            "route": "/client-delivery",
            "status": "later",
            "headline": "Land the handoff into client and team operations.",
            "objective": "Expose client portals, team dashboards, monitoring, documents, and service performance once the platform is live and monetized.",
            "frontend": [
                "Client portal",
                "Team workspace",
                "Admin and super-admin control panels",
            ],
            "backend": [
                "Client accounts and entitlements",
                "Case management and monitoring data",
                "Role-based access and reporting",
            ],
            "deliverables": [
                "Client portal",
                "Team dashboard",
                "Super-admin control plane",
            ],
        },
    ]

    return {
        "flow_name": "Build → Secure → Monetize → Operate",
        "summary": (
            "Use one universal launch flow instead of building every module in parallel. "
            "This sequence reduces complexity and gives the platform a clean path from website creation to production hardening, billing, market launch, and client delivery."
        ),
        "recommended_now": [
            "Website Studio",
            "Infrastructure Console",
        ],
        "decision": {
            "why_this_flow": (
                "The platform currently has enough foundation to render dashboards, admin pages, integrations, and routing. "
                "The highest-leverage next move is to create a public website and infrastructure control layer first, then add security, billing, and market operations."
            ),
            "what_to_avoid": (
                "Do not build client portals, marketplace, social automation, wallets, and Cloudflare governance as disconnected dashboards. "
                "Ship them through one ordered flow with clear release gates."
            ),
        },
        "phases": phases,
    }
