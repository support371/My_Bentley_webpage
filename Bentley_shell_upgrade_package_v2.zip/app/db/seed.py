import logging
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy import select

from app.db.database import AsyncSessionLocal
from app.models.auth import User
from app.models.tenants import Tenant
from app.core.security import hash_password
from app.core.config import settings
from app.services.platform import seed_control_plane_workspaces, seed_module_entities

logger = logging.getLogger("itwin_ops.seed")


async def seed_initial_data():
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Tenant).limit(1))
        existing_tenant = result.scalars().first()

        if not existing_tenant:
            default_tenant = Tenant(
                name="Default Organization",
                slug="default",
                is_active=True,
            )
            session.add(default_tenant)
            await session.commit()
            await session.refresh(default_tenant)

            admin_user = User(
                email=settings.INITIAL_ADMIN_EMAIL,
                hashed_password=hash_password(settings.INITIAL_ADMIN_PASSWORD),
                full_name="Platform Admin",
                role="admin",
                tenant_id=default_tenant.id,
            )
            session.add(admin_user)
            await session.commit()

        await seed_control_plane_workspaces(session)
        await seed_module_entities(session)

        logger.info(f"Seeded platform baseline data: {settings.INITIAL_ADMIN_EMAIL}")
