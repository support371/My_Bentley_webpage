# Replit Update Instruction

Update the app from the current modular Bentley operations baseline, not the old MVP.

Keep these product surfaces active:
- Overview dashboard
- Events
- iTwins
- iModels
- Integrations
- Mobile Ops
- Admin
- Launch Readiness

Preserve the current FastAPI-centered architecture and admin UX, then layer in the broader control-plane and deployment views rather than replacing the core Bentley operations experience.
