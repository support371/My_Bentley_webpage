# Azure DevOps pipeline flow for My_Bentley_webpage

This package includes a backend-first Azure DevOps / AKS rollout scaffold.

Included:
- `.azure-pipelines/aks-pipeline.yml`
- `.azure-pipelines/templates/backend-ci.yml`
- `.azure-pipelines/templates/containerize.yml`
- `.azure-pipelines/templates/deploy-aks.yml`
- `Dockerfile`
- `charts/bentley-fastapi/*`

Manual Azure-side setup still required:
- ACR service connection
- Azure RM service connection
- AKS environment approvals
- Kubernetes secrets or Key Vault integration
- Replacement of placeholder Azure values
