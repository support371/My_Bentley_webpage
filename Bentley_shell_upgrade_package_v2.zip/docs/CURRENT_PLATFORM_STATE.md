# Current Platform State

## What exists now

The app is no longer a simple MVP. It is a modular Bentley operations platform with these active surfaces:

### Core operations
- Overview dashboard
- Event intelligence feed
- iTwins view
- iModels view
- Integrations center
- Admin diagnostics

### Mobile Ops
- Alarms
- Monitors
- Reports
- Admin
- More
- Integrations

### Readiness and strategy
- Launch Readiness center
- Platform Flow view
- Control Plane overview
- Control Plane registry

### Deployment scaffold
- Azure DevOps AKS pipeline entry
- backend CI template
- container build template
- AKS deploy template
- Dockerfile
- Helm chart baseline

## What is still baseline rather than final

- Mobile Ops UI is functional but still a lightweight presentation layer.
- The Helm deployment manifest is intentionally lean.
- Azure-side service connections, variable groups, environment approvals, and secrets are not auto-created.
- The deployment story is scaffolded, not live-wired.

## Current strategic operating path

Build → Secure → Monetize → Publish → Deliver → Operate → Scale

This path is represented in the app through:
- Platform Flow
- Control Plane modules
- Launch Readiness checks
- Deployment scaffold documentation

## What future updates should preserve

- Bentley-native monitoring and event intelligence identity
- modular `app.main:app` runtime
- admin and mobile operations surfaces
- deployment-readiness orientation
- broader enterprise modules exposed through controlled product surfaces
