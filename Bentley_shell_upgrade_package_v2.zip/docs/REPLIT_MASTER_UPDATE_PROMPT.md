# Replit Master Update Prompt

Use this if you need to instruct Replit or another coding assistant to update the project from the current state.

## Instruction

Update this app from the **current modular Bentley operations platform** baseline, not from the old MVP.

### Preserve these active product surfaces
- Overview dashboard
- Events intelligence
- iTwins
- iModels
- Integrations
- Admin
- Launch Readiness
- Platform Flow
- Control Plane
- Control Plane Registry
- Mobile Ops

### Mobile Ops must remain present
- Alarms
- Monitors
- Reports
- Admin
- More
- Integrations

### Preserve the current architecture direction
- modular FastAPI runtime
- `app.main:app` as the canonical entrypoint
- server-rendered admin/ops templates with shared navigation
- JSON/API feeds for operational surfaces
- deployment-readiness and launch-readiness orientation

### Build forward from the current app into this enterprise shape
Add or refine enterprise product surfaces for:
- Website Studio
- Infrastructure Console
- Cloudflare Security
- Billing and Wallet
- Marketplace and News
- Client Delivery
- Operations and deployment center

These modules should feel integrated into the app, seeded with realistic data, and represented as product surfaces even if some deeper workflows remain mocked.

### Add or improve these operational areas
- service configuration center
- website chat readiness
- browser notification readiness
- admin alert routing
- observability status
- CI/CD status
- container status
- AKS / Kubernetes deployment state
- ingress/domain state
- secret/config checklist
- environment promotion controls

### UX expectations
- enterprise-grade
- responsive
- mobile-aware
- clear admin navigation
- clean cards, tables, and charts
- modern but not flashy
- operations-first

### Do not do these things
- do not turn the app into a generic landing page
- do not remove the Bentley operations identity
- do not replace the modular runtime with a new parallel stack
- do not remove Mobile Ops
- do not collapse everything into one page
- do not reintroduce legacy prototype structure

### Current truth to reflect
This app already includes:
- dashboard, events, iTwins, iModels, integrations, admin
- mobile routes and mobile templates
- launch readiness checks
- platform flow and control plane surfaces
- Azure DevOps / AKS deployment scaffold with Dockerfile, pipeline templates, and Helm chart baseline

The update should make the app feel like the latest enterprise version of the Bentley platform after the major discussion decisions, while preserving the real codebase and not inventing a new unrelated architecture.
