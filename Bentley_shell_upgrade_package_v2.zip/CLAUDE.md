# Bentley Platform Context

This project is a modular FastAPI operations platform centered on Bentley iTwin event intelligence, admin diagnostics, mobile operations, and launch/deployment readiness.

## Canonical runtime
- Entry app: `app.main:app`
- Local run: `python run.py`
- Primary web port: `5000`

## Current platform surfaces
- `/dashboard` — overview dashboard
- `/events-view` — event intelligence feed
- `/itwins-view` — iTwin inventory
- `/imodels-view` — iModel inventory
- `/integrations` — integration catalog and connection status
- `/admin` — admin diagnostics and operations
- `/launch-readiness` — production readiness audit
- `/platform-flow` — universal launch / execution path
- `/control-plane` — strategic control-plane modules
- `/control-plane-registry` — workspace registry
- `/mobile/*` — Bentley Mobile Ops surfaces

## Mobile Ops surfaces
- `/mobile/alarms`
- `/mobile/monitors`
- `/mobile/reports`
- `/mobile/admin`
- `/mobile/more`
- `/mobile/integrations`

## API surfaces
- `/health`
- `/api/docs`
- `/api/redoc`
- `/api/platform-flow`
- `/api/launch-readiness`
- `/api/mobile/*`

## Design direction
Preserve the Bentley-native operations identity. Do not collapse the app into a generic landing page. Build forward from the current modular operations baseline while exposing broader enterprise modules through the control-plane.

## Enterprise modules represented in the app
- Website Studio
- Infrastructure Console
- Cloudflare Security
- Billing and Wallet
- Marketplace and News
- Client Delivery

## Deployment scaffold included
- `.azure-pipelines/aks-pipeline.yml`
- `.azure-pipelines/templates/*`
- `Dockerfile`
- `charts/bentley-fastapi/*`

## Non-negotiables
- Keep `app/` as the canonical runtime.
- Keep Mobile Ops as an adapter/presentation layer over shared data and services.
- Do not reintroduce legacy single-file app assumptions.
- Do not commit secrets or tokens into `.replit`, source, or docs.
