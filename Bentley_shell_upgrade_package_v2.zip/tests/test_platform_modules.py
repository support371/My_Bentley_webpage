import pytest


@pytest.mark.anyio
async def test_control_plane_page(client):
    resp = await client.get("/control-plane")
    assert resp.status_code == 200
    assert "Universal Control Plane" in resp.text
    assert "Execution registry" in resp.text


@pytest.mark.anyio
async def test_registry_page(client):
    resp = await client.get("/control-plane-registry")
    assert resp.status_code == 200
    assert "Execution Registry" in resp.text


@pytest.mark.anyio
@pytest.mark.parametrize(
    "path, expected_slug",
    [
        ("/api/website-studio", "website-studio"),
        ("/api/infrastructure-console", "infrastructure-console"),
        ("/api/cloudflare-console", "cloudflare-console"),
        ("/api/billing-wallet", "billing-wallet"),
        ("/api/marketplace-console", "marketplace-console"),
        ("/api/client-delivery", "client-delivery"),
    ],
)
async def test_module_api_aliases(client, path, expected_slug):
    resp = await client.get(path)
    assert resp.status_code == 200
    data = resp.json()
    assert data["slug"] == expected_slug
    assert data["api_endpoints"]
    assert "workspaces" in data
    assert "data_layer" in data


@pytest.mark.anyio
async def test_module_lookup_not_found(client):
    resp = await client.get("/api/control-plane/modules/not-real")
    assert resp.status_code == 404


@pytest.mark.anyio
async def test_create_list_and_update_workspace_via_api(client):
    create_resp = await client.post(
        "/api/control-plane/workspaces",
        json={
            "module_slug": "website-studio",
            "name": "Launch microsite",
            "vertical": "Real Estate",
            "status": "planned",
            "environment": "preview",
            "priority": "high",
            "owner_name": "Growth Team",
            "summary": "Prepare the flagship launch microsite for market release.",
        },
    )
    assert create_resp.status_code == 201, create_resp.text
    created = create_resp.json()

    patch_resp = await client.patch(
        f"/api/control-plane/workspaces/{created['id']}",
        json={"status": "active", "environment": "production"},
    )
    assert patch_resp.status_code == 200
    updated = patch_resp.json()
    assert updated["status"] == "active"
    assert updated["environment"] == "production"

    module_resp = await client.get("/api/control-plane/modules/website-studio")
    assert module_resp.status_code == 200
    module_data = module_resp.json()
    assert module_data["workspace_metrics"]["total"] >= 1
    assert any(item["id"] == created["id"] for item in module_data["workspaces"])


@pytest.mark.anyio
async def test_control_plane_feed_contains_data_layers(client):
    resp = await client.get("/api/control-plane")
    assert resp.status_code == 200
    data = resp.json()
    assert data["modules"]
    assert all("data_layer" in module for module in data["modules"])


@pytest.mark.anyio
async def test_website_secondary_crud_and_release_publish(client):
    project_resp = await client.post(
        "/api/website-studio/projects",
        json={
            "name": "Brand launch site",
            "slug": "brand-launch-site",
            "vertical": "Real Estate",
            "status": "draft",
            "primary_domain": "brand.example.com",
            "owner_name": "Marketing Ops",
            "summary": "Public site for launch, conversion, and service showcase.",
            "is_public": True,
        },
    )
    assert project_resp.status_code == 201, project_resp.text
    project = project_resp.json()

    page_resp = await client.post(
        "/api/website-studio/pages",
        json={
            "project_id": project["id"],
            "title": "Developer Tools",
            "slug": "developer-tools",
            "page_type": "service",
            "status": "draft",
            "hero_title": "Full-stack delivery",
            "seo_title": "Developer Tools | GEM",
            "seo_description": "Development and deployment services.",
            "sort_order": 1,
        },
    )
    assert page_resp.status_code == 201, page_resp.text
    page = page_resp.json()

    section_resp = await client.post(
        "/api/website-studio/sections",
        json={
            "page_id": page["id"],
            "section_key": "hero",
            "title": "Hero",
            "body": "All developer tools are showcased here.",
            "component_type": "hero",
            "sort_order": 1,
            "is_enabled": True,
        },
    )
    assert section_resp.status_code == 201, section_resp.text
    section = section_resp.json()

    release_resp = await client.post(
        "/api/website-studio/releases",
        json={
            "project_id": project["id"],
            "version_label": "v1.0",
            "environment": "production",
            "status": "pending",
            "notes": "Ready for public release.",
        },
    )
    assert release_resp.status_code == 201, release_resp.text
    release = release_resp.json()

    patch_page = await client.patch(f"/api/website-studio/pages/{page['id']}", json={"status": "review"})
    assert patch_page.status_code == 200
    assert patch_page.json()["status"] == "review"

    publish_resp = await client.post(f"/api/website-studio/releases/{release['id']}/publish")
    assert publish_resp.status_code == 200
    assert publish_resp.json()["status"] == "published"

    delete_section = await client.delete(f"/api/website-studio/sections/{section['id']}")
    assert delete_section.status_code == 204


@pytest.mark.anyio
async def test_infrastructure_secondary_crud_and_promote(client):
    project_resp = await client.post(
        "/api/infrastructure-console/projects",
        json={
            "name": "Edge deployment lane",
            "provider": "Cloudflare",
            "target_stack": "FastAPI + Workers",
            "status": "planned",
            "primary_domain": "edge.example.com",
            "repo_url": "https://github.com/example/repo",
            "summary": "Production runtime and release controls.",
        },
    )
    assert project_resp.status_code == 201, project_resp.text
    project = project_resp.json()

    env_resp = await client.post(
        "/api/infrastructure-console/environments",
        json={
            "deployment_project_id": project["id"],
            "name": "production",
            "stage": "production",
            "app_url": "https://edge.example.com",
            "deployment_status": "pending",
            "health_status": "yellow",
            "region": "global",
        },
    )
    assert env_resp.status_code == 201, env_resp.text
    env = env_resp.json()

    domain_resp = await client.post(
        "/api/infrastructure-console/domains",
        json={
            "deployment_project_id": project["id"],
            "hostname": "edge.example.com",
            "dns_provider": "Cloudflare",
            "ssl_mode": "strict",
            "status": "pending",
            "cdn_enabled": True,
        },
    )
    assert domain_resp.status_code == 201, domain_resp.text
    domain = domain_resp.json()

    promote_resp = await client.post(
        f"/api/infrastructure-console/projects/{project['id']}/promote",
        data={"target_environment": "production", "actor_name": "Ops", "detail": "Promoting to production."},
    )
    assert promote_resp.status_code == 200
    assert promote_resp.json()["event_type"] == "promotion"

    env_patch = await client.patch(f"/api/infrastructure-console/environments/{env['id']}", json={"health_status": "green"})
    assert env_patch.status_code == 200
    assert env_patch.json()["health_status"] == "green"

    domain_delete = await client.delete(f"/api/infrastructure-console/domains/{domain['id']}")
    assert domain_delete.status_code == 204


@pytest.mark.anyio
async def test_cloudflare_rule_crud_and_toggle(client):
    zone_resp = await client.post(
        "/api/cloudflare-console/zones",
        json={
            "name": "Corporate zone",
            "zone_name": "corp.example.com",
            "status": "active",
            "ssl_mode": "strict",
            "waf_mode": "managed",
            "cache_strategy": "standard",
            "notes": "Primary edge zone.",
        },
    )
    assert zone_resp.status_code == 201, zone_resp.text
    zone = zone_resp.json()

    rule_resp = await client.post(
        "/api/cloudflare-console/rules",
        json={
            "zone_id": zone["id"],
            "rule_name": "API rate limit",
            "rule_type": "rate-limit",
            "action": "challenge",
            "expression": "http.request.uri.path contains '/api/'",
            "status": "active",
            "priority": 10,
        },
    )
    assert rule_resp.status_code == 201, rule_resp.text
    rule = rule_resp.json()

    toggle_resp = await client.post(f"/api/cloudflare-console/rules/{rule['id']}/toggle")
    assert toggle_resp.status_code == 200
    assert toggle_resp.json()["status"] == "disabled"

    patch_resp = await client.patch(f"/api/cloudflare-console/rules/{rule['id']}", json={"action": "block", "status": "active"})
    assert patch_resp.status_code == 200
    assert patch_resp.json()["action"] == "block"

    delete_resp = await client.delete(f"/api/cloudflare-console/rules/{rule['id']}")
    assert delete_resp.status_code == 204


@pytest.mark.anyio
async def test_billing_gateway_wallet_flows(client):
    plan_resp = await client.post(
        "/api/billing-wallet/plans",
        json={
            "name": "Enterprise Vault",
            "vertical": "Cybersecurity",
            "billing_provider": "Stripe",
            "cadence": "monthly",
            "price_label": "$999 / month",
            "currency": "USD",
            "status": "live",
            "summary": "Recurring billing with wallet-linked checkout.",
        },
    )
    assert plan_resp.status_code == 201, plan_resp.text
    plan = plan_resp.json()

    gateway_resp = await client.post(
        "/api/billing-wallet/gateways",
        json={
            "gateway_name": "Coinbase Commerce",
            "gateway_type": "web3",
            "settlement_asset": "USDC",
            "status": "configured",
            "webhook_status": "healthy",
            "notes": "Crypto checkout lane.",
        },
    )
    assert gateway_resp.status_code == 201, gateway_resp.text
    gateway = gateway_resp.json()

    wallet_resp = await client.post(
        "/api/billing-wallet/wallets",
        json={
            "wallet_name": "Executive Treasury",
            "wallet_type": "user-controlled",
            "owner_scope": "personal",
            "network": "Base",
            "custody_model": "self-custody",
            "address_hint": "0xAB...1234",
            "status": "configured",
        },
    )
    assert wallet_resp.status_code == 201, wallet_resp.text
    wallet = wallet_resp.json()

    activate_resp = await client.post(f"/api/billing-wallet/wallets/{wallet['id']}/activate")
    assert activate_resp.status_code == 200
    assert activate_resp.json()["status"] == "active"

    patch_gateway = await client.patch(f"/api/billing-wallet/gateways/{gateway['id']}", json={"status": "live"})
    assert patch_gateway.status_code == 200
    assert patch_gateway.json()["status"] == "live"

    delete_plan = await client.delete(f"/api/billing-wallet/plans/{plan['id']}")
    assert delete_plan.status_code == 204


@pytest.mark.anyio
async def test_marketplace_article_newsletter_flows(client):
    offer_resp = await client.post(
        "/api/marketplace-console/offers",
        json={
            "name": "Launch offer",
            "vertical": "Cybersecurity",
            "channel": "Marketplace",
            "price_model": "Subscription",
            "status": "draft",
            "summary": "Offer seeded from the module form.",
        },
    )
    assert offer_resp.status_code == 201, offer_resp.text
    offer = offer_resp.json()

    article_resp = await client.post(
        "/api/marketplace-console/articles",
        json={
            "title": "Daily threat digest",
            "slug": "daily-threat-digest",
            "source_name": "Telegram",
            "status": "queued",
            "image_url": "/static/img/news-card.png",
            "description": "Fresh content for the news feed.",
            "body": "Detailed body for the news article.",
        },
    )
    assert article_resp.status_code == 201, article_resp.text
    article = article_resp.json()

    newsletter_resp = await client.post(
        "/api/marketplace-console/newsletters",
        json={
            "title": "Platform Pulse #2",
            "audience": "Clients",
            "status": "draft",
            "send_window": "08:00 ET",
            "hero_story": "Main story summary.",
        },
    )
    assert newsletter_resp.status_code == 201, newsletter_resp.text
    newsletter = newsletter_resp.json()

    publish_resp = await client.post(f"/api/marketplace-console/articles/{article['id']}/publish")
    assert publish_resp.status_code == 200
    assert publish_resp.json()["status"] == "published"

    schedule_resp = await client.post(
        f"/api/marketplace-console/newsletters/{newsletter['id']}/schedule",
        data={"send_window": "09:30 ET"},
    )
    assert schedule_resp.status_code == 200
    assert schedule_resp.json()["status"] == "scheduled"
    assert schedule_resp.json()["send_window"] == "09:30 ET"

    delete_offer = await client.delete(f"/api/marketplace-console/offers/{offer['id']}")
    assert delete_offer.status_code == 204


@pytest.mark.anyio
async def test_client_delivery_team_portfolio_flows(client):
    client_resp = await client.post(
        "/api/client-delivery/clients",
        json={
            "name": "Flagship Holdings",
            "vertical": "Real Estate",
            "primary_contact": "client@example.com",
            "service_tier": "Enterprise",
            "status": "active",
            "summary": "Client delivery scope.",
        },
    )
    assert client_resp.status_code == 201, client_resp.text
    client_row = client_resp.json()

    team_resp = await client.post(
        "/api/client-delivery/teams",
        json={
            "name": "Real Estate Delivery Team",
            "client_account_id": None,
            "vertical": "Real Estate",
            "team_type": "delivery",
            "member_capacity": 50,
            "status": "active",
            "summary": "Dedicated real estate team.",
        },
    )
    assert team_resp.status_code == 201, team_resp.text
    team = team_resp.json()

    assign_resp = await client.post(
        f"/api/client-delivery/teams/{team['id']}/assign-client",
        data={"client_account_id": client_row['id']},
    )
    assert assign_resp.status_code == 200
    assert assign_resp.json()["client_account_id"] == client_row["id"]

    portfolio_resp = await client.post(
        "/api/client-delivery/portfolios",
        json={
            "client_account_id": client_row["id"],
            "team_workspace_id": team["id"],
            "service_name": "Managed Security Operations",
            "category": "Managed Service",
            "status": "planned",
            "renewal_window": "Q4 review",
            "notes": "Portfolio notes.",
        },
    )
    assert portfolio_resp.status_code == 201, portfolio_resp.text
    portfolio = portfolio_resp.json()

    activate_resp = await client.post(
        f"/api/client-delivery/portfolios/{portfolio['id']}/activate",
        data={"team_workspace_id": team['id']},
    )
    assert activate_resp.status_code == 200
    assert activate_resp.json()["status"] == "active"

    patch_team = await client.patch(f"/api/client-delivery/teams/{team['id']}", json={"member_capacity": 60})
    assert patch_team.status_code == 200
    assert patch_team.json()["member_capacity"] == 60

    delete_portfolio = await client.delete(f"/api/client-delivery/portfolios/{portfolio['id']}")
    assert delete_portfolio.status_code == 204


@pytest.mark.anyio
async def test_form_routes_for_secondary_records_and_actions(client):
    project_resp = await client.post(
        "/control-plane/modules/website-studio/records/create",
        data={
            "name": "Form project",
            "slug": "form-project",
            "vertical": "Cybersecurity",
            "status": "draft",
            "primary_domain": "form.example.com",
        },
        follow_redirects=False,
    )
    assert project_resp.status_code == 303

    projects = (await client.get("/api/website-studio/projects")).json()
    project = next(row for row in projects if row["slug"] == "form-project")

    page_resp = await client.post(
        "/control-plane/modules/website-studio/records/pages/create",
        data={
            "project_id": project["id"],
            "title": "Form page",
            "slug": "form-page",
            "page_type": "service",
            "status": "draft",
        },
        follow_redirects=False,
    )
    assert page_resp.status_code == 303

    release_resp = await client.post(
        "/control-plane/modules/website-studio/records/releases/create",
        data={
            "project_id": project["id"],
            "version_label": "v2.0",
            "environment": "production",
            "status": "pending",
        },
        follow_redirects=False,
    )
    assert release_resp.status_code == 303

    releases = (await client.get("/api/website-studio/releases")).json()
    release = next(row for row in releases if row["version_label"] == "v2.0")

    publish_resp = await client.post(
        "/control-plane/modules/website-studio/actions/publish-release",
        data={"release_id": release["id"]},
        follow_redirects=False,
    )
    assert publish_resp.status_code == 303

    release_rows = (await client.get("/api/website-studio/releases")).json()
    published = next(row for row in release_rows if row["id"] == release["id"])
    assert published["status"] == "published"
