# Bentley iTwin Operations Center

A modular FastAPI operations platform for Bentley iTwin event intelligence, admin diagnostics, integration management, mobile operations, and deployment readiness.

## Current platform surfaces

- Overview dashboard
- Events intelligence feed
- iTwins and iModels inventory views
- Integrations center
- Admin diagnostics and Bentley readiness
- Mobile Ops: alarms, monitors, reports, admin, more, integrations
- Launch Readiness center
- Azure DevOps / AKS deployment scaffold

## Runtime

- Entry app: `app.main:app`
- Default port: `5000`
- Local run: `python run.py` or `uvicorn app.main:app --host 0.0.0.0 --port 5000`

## Ops checks

```bash
python -m compileall app tests
bash smoke-test.sh
```

## Deployment scaffold included

- `.azure-pipelines/aks-pipeline.yml`
- `.azure-pipelines/templates/*`
- `Dockerfile`
- `charts/bentley-fastapi/*`
- `docs/azure-devops-pipeline-flow.md`

## Production notes

Before public deployment, replace development defaults for:

- `SECRET_KEY`
- `INITIAL_ADMIN_PASSWORD`
- `WEBHOOK_SECRET`
- `COOKIE_SECURE`
- `PUBLIC_BASE_URL`
- `DATABASE_URL`
- Bentley API credentials

This package is the cleaned shell-built upgrade path and removes old MVP clutter and embedded secrets from the Replit config.


## Route map

### Core
- `/dashboard`
- `/events-view`
- `/itwins-view`
- `/imodels-view`
- `/integrations`
- `/admin`
- `/launch-readiness`
- `/platform-flow`
- `/control-plane`
- `/control-plane-registry`

### Mobile Ops
- `/mobile/alarms`
- `/mobile/monitors`
- `/mobile/reports`
- `/mobile/admin`
- `/mobile/more`
- `/mobile/integrations`

## Assistant handoff files

- `CLAUDE.md`
- `docs/CURRENT_PLATFORM_STATE.md`
- `docs/REPLIT_MASTER_UPDATE_PROMPT.md`
- `docs/REPLIT_UPDATE_INSTRUCTION.md`
